import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

// 鸡汤语录数据
const CHICKEN_SOUP_QUOTES = [
  {
    id: 1,
    content: '生活不会总是一帆风顺，但请相信，那些打不垮你的，终将使你更强。慢慢来，你已经做得很好了，给自己一点时间，阳光总会穿过云层，照亮你的世界。',
    source: '魔丸语录'
  },
  {
    id: 2,
    content: '别急着，你看这年复一年，春光不必趁早，冬霜不会迟到，相聚别离，都是刚刚好。慢慢来，一切都会在最合适的时候到来。',
    source: '魔丸语录'
  },
  {
    id: 3,
    content: '你已经很努力了，不要因为别人的节奏而打乱自己的步伐。每个人都有自己的时区，慢慢来，你会在属于自己的时间里，绽放出最美的花朵。',
    source: '魔丸语录'
  },
  {
    id: 4,
    content: '生命的美好，在于过程中的每一次相遇和成长。不要害怕失败，不要畏惧未知，勇敢地向前走，你会发现，世界比你想象的更精彩。',
    source: '魔丸语录'
  },
  {
    id: 5,
    content: '请记住，你值得被爱，值得拥有美好的一切。不要因为别人的评价而否定自己，你就是独一无二的，你的存在本身就有意义。',
    source: '魔丸语录'
  }
];

// 推荐语录数据（可以与上面相同，这里为了演示复制了部分）
const RECOMMENDED_QUOTES = [
  {
    id: 2,
    content: '别急着，你看这年复一年，春光不必趁早，冬霜不会迟到，相聚别离，都是刚刚好。慢慢来，一切都会在最合适的时候到来。',
    source: '魔丸语录'
  },
  {
    id: 3,
    content: '你已经很努力了，不要因为别人的节奏而打乱自己的步伐。每个人都有自己的时区，慢慢来，你会在属于自己的时间里，绽放出最美的花朵。',
    source: '魔丸语录'
  }
];

const FengYanFengYuPage: React.FC = () => {
  // 控制魔丸弹窗的状态
  const [showMowanPopup, setShowMowanPopup] = useState(false);
  const navigate = useNavigate();
  const [currentQuote, setCurrentQuote] = useState(CHICKEN_SOUP_QUOTES[0]);
  const [isCollected, setIsCollected] = useState(false);
  const [mode, setMode] = useState<'bright' | 'soft' | 'dark'>('soft');
  const [fontSize, setFontSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [collectedQuotes, setCollectedQuotes] = useState<number[]>([]);
  const [showAllQuotesModal, setShowAllQuotesModal] = useState(false);

  // 根据模式获取样式
  const getModeStyles = () => {
    switch (mode) {
      case 'bright':
        return {
          bg: 'bg-white',
          text: 'text-gray-800',
          card: 'bg-white border border-gray-200 shadow-md',
          button: 'bg-gradient-to-r from-orange-400 to-red-500 text-white',
          buttonHover: 'from-orange-500 to-red-600',
          iconBtn: 'hover:bg-gray-200',
          secondaryBtn: 'bg-blue-500 text-white'
        };
      case 'soft':
        return {
          bg: 'bg-amber-50',
          text: 'text-gray-700',
          card: 'bg-amber-100/80 border border-amber-200 shadow-sm',
          button: 'bg-gradient-to-r from-amber-500 to-orange-500 text-white',
          buttonHover: 'from-amber-600 to-orange-600',
          iconBtn: 'hover:bg-amber-200',
          secondaryBtn: 'bg-amber-600 text-white'
        };
      case 'dark':
        return {
          bg: 'bg-gray-900',
          text: 'text-gray-200',
          card: 'bg-gray-800 border border-gray-700 shadow-lg',
          button: 'bg-gradient-to-r from-purple-600 to-pink-600 text-white',
          buttonHover: 'from-purple-700 to-pink-700',
          iconBtn: 'hover:bg-gray-700',
          secondaryBtn: 'bg-purple-700 text-white'
        };
      default:
        return {
          bg: 'bg-amber-50',
          text: 'text-gray-700',
          card: 'bg-amber-100/80 border border-amber-200 shadow-sm',
          button: 'bg-gradient-to-r from-amber-500 to-orange-500 text-white',
          buttonHover: 'from-amber-600 to-orange-600',
          iconBtn: 'hover:bg-amber-200',
          secondaryBtn: 'bg-amber-600 text-white'
        };
    }
  };

  // 获取字体大小样式
  const getFontSizeStyles = () => {
    switch (fontSize) {
      case 'small':
        return 'text-sm';
      case 'medium':
        return 'text-base';
      case 'large':
        return 'text-lg';
      default:
        return 'text-base';
    }
  };

  // 更换随机语录
  const changeQuote = () => {
    const randomIndex = Math.floor(Math.random() * CHICKEN_SOUP_QUOTES.length);
    const newQuote = CHICKEN_SOUP_QUOTES[randomIndex];
    setCurrentQuote(newQuote);
    setIsCollected(collectedQuotes.includes(newQuote.id));
  };

  // 收藏/取消收藏语录
  const toggleCollection = () => {
    if (isCollected) {
      setCollectedQuotes(collectedQuotes.filter(id => id !== currentQuote.id));
    } else {
      setCollectedQuotes([...collectedQuotes, currentQuote.id]);
    }
    setIsCollected(!isCollected);
  };

  const styles = getModeStyles();
  const fontSizeClass = getFontSizeStyles();

  return (
    <div className={`min-h-screen ${styles.bg} ${styles.text} transition-colors duration-300`}>
      {/* 顶部导航栏 */}
      <nav className="sticky top-0 z-10 backdrop-blur-md bg-opacity-80 border-b border-gray-200 dark:border-gray-700" style={{ backgroundColor: mode === 'dark' ? 'rgba(31, 41, 55, 0.8)' : mode === 'bright' ? 'rgba(255, 255, 255, 0.8)' : 'rgba(254, 243, 199, 0.8)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <button 
                onClick={() => navigate(-1)} 
                className={`p-2 rounded-full ${styles.iconBtn} transition-colors duration-200`}
              >
                <i className="fa fa-arrow-left"></i>
              </button>
              <h1 className="ml-4 text-xl font-bold">锋言锋语</h1>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-3xl mx-auto px-4 py-8">
        {/* 主鸡汤卡片 */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className={`${styles.card} rounded-xl p-6 mb-8`}
        >
          <h2 
            className="text-2xl font-bold text-center mb-2 bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent cursor-pointer hover:opacity-90 transition-opacity"
            onClick={() => setShowMowanPopup(true)}
            title="点击查看魔丸的哼哼"
          >
            魔丸魔语
          </h2>
          <p className="text-center text-sm mb-6 opacity-80">给心灵一份温柔的力量，让生活充满温暖与希望</p>
          
          <div className={`p-6 rounded-lg bg-opacity-50 mb-6 ${fontSizeClass} leading-relaxed`} style={{ backgroundColor: mode === 'dark' ? 'rgba(55, 65, 81, 0.5)' : mode === 'bright' ? 'rgba(249, 250, 251, 0.5)' : 'rgba(254, 249, 195, 0.5)' }}>
            <p className="mb-4">{currentQuote.content}</p>
            <p className="text-right italic">—{currentQuote.source.replace('温暖', '魔丸')}</p>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="flex space-x-2">
              <button 
                onClick={toggleCollection}
                className={`p-2 rounded-full ${styles.iconBtn} transition-colors duration-200 flex items-center`}
              >
                <i className={`fa ${isCollected ? 'fa-heart text-red-500' : 'fa-heart-o'} mr-1`}></i>
                {isCollected ? '已收藏' : '收藏'}
              </button>
            </div>
            <button 
              onClick={changeQuote}
              className={`px-4 py-2 rounded-full bg-gradient-to-r ${styles.button} hover:from-amber-600 hover:to-orange-600 transition-all duration-200 transform hover:scale-105 flex items-center`}
            >
              <i className="fa fa-refresh mr-2"></i>
              换一句温暖
            </button>
          </div>
        </motion.div>

        {/* 设置区域 */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className={`${styles.card} rounded-xl p-6 mb-8`}
        >
          <h3 className="text-lg font-semibold mb-4">模式切换</h3>
          <div className="flex space-x-4 mb-6">
            <button 
              onClick={() => setMode('bright')}
              className={`px-4 py-2 rounded-full transition-all duration-200 ${mode === 'bright' ? 'bg-gray-200 dark:bg-gray-700 font-medium' : styles.iconBtn}`}
            >
              <i className="fa fa-sun-o mr-1"></i> 明亮模式
            </button>
            <button 
              onClick={() => setMode('soft')}
              className={`px-4 py-2 rounded-full transition-all duration-200 ${mode === 'soft' ? 'bg-amber-200 dark:bg-amber-900/50 font-medium' : styles.iconBtn}`}
            >
              <i className="fa fa-moon-o mr-1"></i> 柔和模式
            </button>
            <button 
              onClick={() => setMode('dark')}
              className={`px-4 py-2 rounded-full transition-all duration-200 ${mode === 'dark' ? 'bg-gray-700 dark:bg-gray-600 font-medium' : styles.iconBtn}`}
            >
              <i className="fa fa-star-o mr-1"></i> 暗黑系统
            </button>
          </div>
          
          <h3 className="text-lg font-semibold mb-4">字体调整</h3>
          <div className="flex space-x-4">
            <button 
              onClick={() => setFontSize('small')}
              className={`px-4 py-2 rounded-full transition-all duration-200 ${fontSize === 'small' ? `${styles.button} font-medium` : styles.iconBtn}`}
            >
              A- A-
            </button>
            <button 
              onClick={() => setFontSize('medium')}
              className={`px-4 py-2 rounded-full transition-all duration-200 ${fontSize === 'medium' ? `${styles.button} font-medium` : styles.iconBtn}`}
            >
              默认
            </button>
            <button 
              onClick={() => setFontSize('large')}
              className={`px-4 py-2 rounded-full transition-all duration-200 ${fontSize === 'large' ? `${styles.button} font-medium` : styles.iconBtn}`}
            >
              A+ A+
            </button>
          </div>
        </motion.div>

        {/* 我的收藏 */}
        {collectedQuotes.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className={`${styles.card} rounded-xl p-6 mb-8`}
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">我的收藏</h3>
            </div>
            <div className="space-y-4">
              {collectedQuotes.map(id => {
                const quote = CHICKEN_SOUP_QUOTES.find(q => q.id === id);
                if (!quote) return null;
                return (
                  <div key={id} className={`p-4 rounded-lg bg-opacity-50 ${fontSizeClass} leading-relaxed`} style={{ backgroundColor: mode === 'dark' ? 'rgba(55, 65, 81, 0.5)' : mode === 'bright' ? 'rgba(249, 250, 251, 0.5)' : 'rgba(254, 249, 195, 0.5)' }}>
                    <p className="mb-2">{quote.content}</p>
                    <p className="text-right italic">—{quote.source}</p>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* 推荐魔丸语录 */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className={`${styles.card} rounded-xl p-6`}
        >
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">推荐魔丸语录</h3>
            <button 
              className={`px-4 py-1 rounded-full text-sm ${styles.secondaryBtn} hover:opacity-90 transition-opacity`}
              onClick={() => setShowAllQuotesModal(true)}
            >
              查看全部
            </button>
          </div>
          <div className="space-y-4">
            {RECOMMENDED_QUOTES.map(quote => (
              <div key={quote.id} className={`p-4 rounded-lg bg-opacity-50 ${fontSizeClass} leading-relaxed`} style={{ backgroundColor: mode === 'dark' ? 'rgba(55, 65, 81, 0.5)' : mode === 'bright' ? 'rgba(249, 250, 251, 0.5)' : 'rgba(254, 249, 195, 0.5)' }}>
                <p className="mb-2">{quote.content}</p>
                <div className="flex justify-between items-center">
                  <p className="text-right italic">—{quote.source}</p>
                  <button className={`p-1 rounded-full ${styles.iconBtn} transition-colors duration-200`}>
                    <i className="fa fa-heart-o"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </main>

      {/* 全部语录弹窗 */}
      <AnimatePresence>
        {showAllQuotesModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
            onClick={() => setShowAllQuotesModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className={`${styles.card} rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto`}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">全部魔丸语录</h3>
                <button 
                  className={`p-2 rounded-full ${styles.iconBtn} transition-colors duration-200`}
                  onClick={() => setShowAllQuotesModal(false)}
                >
                  <i className="fa fa-times"></i>
                </button>
              </div>
              
              <div className="space-y-6">
                {CHICKEN_SOUP_QUOTES.map(quote => (
                  <motion.div 
                    key={quote.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: quote.id * 0.1 }}
                    className={`p-5 rounded-lg bg-opacity-50 ${fontSizeClass} leading-relaxed`}
                    style={{ backgroundColor: mode === 'dark' ? 'rgba(55, 65, 81, 0.5)' : mode === 'bright' ? 'rgba(249, 250, 251, 0.5)' : 'rgba(254, 249, 195, 0.5)' }}
                  >
                    <p className="mb-3">{quote.content}</p>
                    <div className="flex justify-between items-center">
                      <p className="text-right italic">—{quote.source}</p>
                      <button 
                        className={`p-2 rounded-full ${styles.iconBtn} transition-colors duration-200`}
                        onClick={() => {
                          if (!collectedQuotes.includes(quote.id)) {
                            setCollectedQuotes([...collectedQuotes, quote.id]);
                          }
                        }}
                        disabled={collectedQuotes.includes(quote.id)}
                      >
                        <i className={`fa ${collectedQuotes.includes(quote.id) ? 'fa-heart text-red-500' : 'fa-heart-o'}`}></i>
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* 魔丸弹窗 */}
      <AnimatePresence>
        {showMowanPopup && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowMowanPopup(false)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", damping: 20 }}
              className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-md w-full shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-xl font-bold mb-4 text-center bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">魔丸的哼哼</h3>
              <p className="text-gray-700 dark:text-gray-300 text-center mb-6">我是魔丸，我告诉你，不要在这样了</p>
              <div className="flex justify-center">
                <button
                  className="px-6 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-full hover:opacity-90 transition-opacity"
                  onClick={() => setShowMowanPopup(false)}
                >
                  我知道了
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FengYanFengYuPage;
