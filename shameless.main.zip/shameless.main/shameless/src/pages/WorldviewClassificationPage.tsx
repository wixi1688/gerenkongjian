import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useThemeContext } from '../contexts/ThemeContext';

const WorldviewClassificationPage: React.FC = () => {
  const navigate = useNavigate();
  const { theme } = useThemeContext();
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = 1;
  const [selectedCategory, setSelectedCategory] = useState<string | null>('unknown-1');
  const [showModal, setShowModal] = useState(false); // 控制信息弹窗显示
  const [showTitleModal, setShowTitleModal] = useState(false); // 控制标题弹窗显示

  // 世界观分类数据，添加了颜色主题
  const categories = [
    {
      id: 'unknown-1',
      name: '未知',
      description: '未知',
      colorClass: 'bg-gradient-to-r from-purple-600/20 to-blue-600/20 border-purple-500/40',
      iconColor: 'border-purple-500 text-purple-400'
    },
    {
      id: 'unknown-2',
      name: '',
      description: '',
      colorClass: 'bg-gradient-to-r from-blue-600/20 to-teal-600/20 border-blue-500/40',
      iconColor: 'border-blue-500'
    },
    {
      id: 'unknown-3',
      name: '',
      description: '',
      colorClass: 'bg-gradient-to-r from-teal-600/20 to-green-600/20 border-teal-500/40',
      iconColor: 'border-teal-500'
    },
    {
      id: 'unknown-4',
      name: '',
      description: '',
      colorClass: 'bg-gradient-to-r from-green-600/20 to-yellow-600/20 border-green-500/40',
      iconColor: 'border-green-500'
    }
  ];

  // 返回上一页
  const handleBack = () => {
    navigate(-1);
  };

  // 显示弹窗
  const handleShowModal = () => {
    setShowModal(true);
  };
  
  // 关闭信息弹窗
  const handleCloseModal = () => {
    setShowModal(false);
  };
  
  // 显示标题弹窗
  const handleShowTitleModal = () => {
    setShowTitleModal(true);
  };
  
  // 关闭标题弹窗
  const handleCloseTitleModal = () => {
    setShowTitleModal(false);
  };
  
  // 选择分类
  const handleSelectCategory = (categoryId: string) => {
    setSelectedCategory(categoryId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-indigo-950 to-blue-900 flex flex-col items-center justify-start pt-8 px-4">
      {/* 顶部导航栏 */}
      <motion.div 
        className="w-full max-w-md bg-gray-800/80 backdrop-blur-md rounded-xl border border-blue-500/40 p-3 mb-6 flex items-center justify-between shadow-lg shadow-blue-900/20"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* 返回按钮 */}
        <motion.button
          whileHover={{ scale: 1.1, backgroundColor: 'rgba(59, 130, 246, 0.2)' }}
          whileTap={{ scale: 0.95 }}
          onClick={handleBack}
          className="flex items-center gap-1 text-blue-400 hover:text-blue-300 px-3 py-1.5 rounded-full transition-all"
          aria-label="返回"
        >
          <i className="fa-solid fa-arrow-left"></i>
          <span>返回</span>
        </motion.button>

        {/* 标题 */}
        <motion.h1 
          className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent cursor-pointer"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleShowTitleModal}
          role="button"
          aria-label="点击查看世界观分类说明"
        >世界观分类</motion.h1>

        {/* 信息按钮 */}
        <motion.button
          whileHover={{ scale: 1.1, backgroundColor: 'rgba(59, 130, 246, 0.2)' }}
          whileTap={{ scale: 0.95 }}
          onClick={handleShowModal}
          className="p-1.5 rounded-full transition-all text-blue-400 hover:text-blue-300"
          aria-label="查看世界观说明"
        >
          <i className="fa-solid fa-info-circle"></i>
        </motion.button>
      </motion.div>

      {/* 内容区域 */}
      <motion.div 
        className="w-full max-w-md bg-gray-800/80 backdrop-blur-md rounded-xl border border-blue-500/40 p-4 mb-6 shadow-lg shadow-blue-900/20"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        {/* 第一个分类项 - 有文字 */}
        <motion.div 
          className={`rounded-lg p-3 mb-4 flex items-center gap-4 border ${categories[0].colorClass} ${selectedCategory === categories[0].id ? 'ring-2 ring-purple-400 ring-opacity-50' : ''}`}
          whileHover={{ scale: 1.02, boxShadow: '0 0 15px rgba(147, 51, 234, 0.3)' }}
          whileTap={{ scale: 0.98 }}
          onClick={() => handleSelectCategory(categories[0].id)}
          transition={{ duration: 0.2 }}
        >
          <div className={`w-10 h-10 rounded-full border-2 ${categories[0].iconColor} flex items-center justify-center font-medium`}>
            未知
          </div>
          <div className="text-white font-medium">未知</div>
        </motion.div>

        {/* 其他分类项 - 仅圆形选择器 */}
        {categories.slice(1).map((category, index) => (
          <motion.div 
            key={category.id}
            className={`rounded-lg p-3 mb-4 flex items-center gap-4 border ${category.colorClass} ${selectedCategory === category.id ? `ring-2 ring-${category.iconColor.split('-')[1]}-400 ring-opacity-50` : ''}`}
            whileHover={{ scale: 1.02, boxShadow: `0 0 15px rgba(${index === 0 ? '59, 130, 246' : index === 1 ? '20, 184, 166' : '34, 197, 94'}, 0.3)` }}
            whileTap={{ scale: 0.98 }}
            onClick={() => handleSelectCategory(category.id)}
            transition={{ duration: 0.2 }}
          >
            <div className={`w-10 h-10 rounded-full border-2 ${category.iconColor} flex items-center justify-center`}>
              <motion.div 
                className={`w-4 h-4 rounded-full ${selectedCategory === category.id ? `bg-${category.iconColor.split('-')[1]}-400` : 'bg-gray-600'}`}
                animate={selectedCategory === category.id ? { scale: [1, 1.2, 1] } : {}}
                transition={{ duration: 0.3, repeat: 0 }}
              ></motion.div>
            </div>
            <div className="flex-1 text-gray-400">未知</div>
          </motion.div>
        ))}
      </motion.div>

      {/* 底部页码栏 */}
      <motion.div 
        className="w-full max-w-md bg-gray-800/80 backdrop-blur-md rounded-xl border border-blue-500/40 p-3 flex items-center justify-between shadow-lg shadow-blue-900/20"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <div className="text-blue-400">页码</div>
        <div className="text-white font-medium">{currentPage} / {totalPages}</div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="text-blue-400/50 flex items-center gap-1 cursor-not-allowed px-3 py-1.5 rounded-full transition-all"
          disabled
        >
          <span>下一页</span>
          <i className="fa-solid fa-arrow-right"></i>
        </motion.button>
      </motion.div>

      {/* 装饰元素 - 增强色彩效果 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          className="absolute -top-20 -right-20 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.2, 0.3, 0.2]
          }}
          transition={{ 
            duration: 8, 
            repeat: Infinity,
            repeatType: "reverse"
          }}
        ></motion.div>
        <motion.div 
          className="absolute -bottom-40 -left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.25, 0.2]
          }}
          transition={{ 
            duration: 6, 
            repeat: Infinity,
            repeatType: "reverse"
          }}
        ></motion.div>
        <motion.div 
          className="absolute top-1/3 left-1/4 w-64 h-64 bg-teal-500/15 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.3, 1],
            opacity: [0.1, 0.2, 0.1]
          }}
          transition={{ 
            duration: 10, 
            repeat: Infinity,
            repeatType: "reverse"
          }}
        ></motion.div>
      </div>
      
      {/* 信息弹窗组件 */}
      {showModal && (
        <motion.div
          className="fixed inset-0 flex items-center justify-center bg-black/70 backdrop-blur-sm z-50 p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleCloseModal}
        >
          <motion.div
            className="w-full max-w-md bg-gray-800/95 backdrop-blur-md rounded-xl border border-blue-500/40 p-6 shadow-xl"
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">世界观说明</h3>
              <button
                onClick={handleCloseModal}
                className="text-gray-400 hover:text-white transition-colors p-1"
                aria-label="关闭"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="text-gray-300 space-y-3 text-sm leading-relaxed">
              <p>世界观是人们对整个世界的根本看法和观点体系，它如同心灵的地图，指引着个体如何理解宇宙的起源、生命的意义、善恶的标准以及人与自然、社会的关系。</p>
              <p>有人将世界视为理性构建的精密系统，追求科学与逻辑的终极答案；有人则以诗意的目光拥抱世界，在山川星辰中感知生命的韵律；还有人在多元文化的碰撞中形成开放包容的视野，承认差异并寻求共识。</p>
              <p>世界观没有绝对的对错，它既是个体成长的精神基石，也是人类文明多样性的生动体现，塑造着每个人独特的生命轨迹和价值选择。</p>
            </div>
            <div className="mt-6 flex justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleCloseModal}
                className="px-4 py-2 bg-blue-600/70 hover:bg-blue-500/70 text-white rounded-full transition-all"
              >
                我知道了
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
      
      {/* 标题弹窗组件 */}
      {showTitleModal && (
        <motion.div
          className="fixed inset-0 flex items-center justify-center bg-black/70 backdrop-blur-sm z-50 p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleCloseTitleModal}
        >
          <motion.div
            className="w-full max-w-md bg-gray-800/95 backdrop-blur-md rounded-xl border border-purple-500/40 p-6 shadow-xl"
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">异想世界</h3>
              <button
                onClick={handleCloseTitleModal}
                className="text-gray-400 hover:text-white transition-colors p-1"
                aria-label="关闭"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="text-gray-300 space-y-4 text-sm leading-relaxed">
              <p>我总觉得时钟在撒谎——秒针走得快时，窗外的树影纹丝不动；等我数到第17片叶子落下，墙上的时间才跳了一格。</p>
              <p>他们说这是注意力不集中，但我分明看见桌布上的格子在呼吸，深棕色的木纹里藏着细碎的光斑，像谁把星星揉碎了撒进去。</p>
              <p>最奇怪的是声音会沉淀，昨天的对话今天还浮在玻璃杯底，晃一晃就能听见妈妈说"早点回家"的尾音。</p>
              <p>你们说这是记忆混乱，可对我而言，世界只是不愿意被框在时刻表和逻辑里罢了。</p>
            </div>
            <div className="mt-6 flex justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleCloseTitleModal}
                className="px-4 py-2 bg-purple-600/70 hover:bg-purple-500/70 text-white rounded-full transition-all"
              >
                我知道了
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default WorldviewClassificationPage;