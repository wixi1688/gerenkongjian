import { useEffect, useState } from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import GuideBook from './pages/GuideBook';
import StoryPage from './pages/StoryPage';
import SideStoryPage from './pages/SideStoryPage';
import StoryBranchPage from './pages/StoryBranchPage';
import StoryMajorEventsPage from './pages/StoryMajorEventsPage';
import StoryIntroductionPage from './pages/StoryIntroductionPage';
import CharacterRelationships from './pages/CharacterRelationships';
import MailPage from './pages/MailPage';
import SpecialLevelBattle from './pages/SpecialLevelBattle';
import NewWorldPage from './pages/NewWorldPage';
import FengYanFengYuPage from './pages/FengYanFengYuPage';
import WorldviewClassificationPage from './pages/WorldviewClassificationPage';
import { ThemeProvider } from './contexts/ThemeContext';
import MusicPlayer from './components/MusicPlayer';
import Empty from './components/Empty';
import { AuthProvider, useAuth } from './contexts/authContext';
import LoginPage from './pages/LoginPage';
import PrivatePage from './pages/PrivatePage';

// 顶部进度条组件
const TopProgressBar = ({ loading = false }: { loading?: boolean }) => {
  const [width, setWidth] = useState(0);
  useEffect(() => {
    let raf: number;
    let start: number | null = null;
    const step = (ts: number) => {
      if (start === null) start = ts;
      const elapsed = ts - start;
      const target = loading ? 95 : 100;
      const next = Math.min(target, 10 + elapsed / 8);
      setWidth(next);
      if (next < target) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [loading]);
  return (
    <div className="fixed top-0 left-0 right-0 h-1 z-50">
      <div className="w-full h-full bg-transparent" />
      <div className="h-full bg-blue-500 [transition:width_200ms_cubic-bezier(0.4,0,0.2,1)]" style={{ width: `${width}%` }} />
    </div>
  );
};

const RequireAuth = ({ children }: { children: JSX.Element }) => {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return children;
};

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
      <TopProgressBar />
      {/* 移除Suspense，因为不再使用动态导入 */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/game" element={<Home />} />
        <Route path="/guidebook" element={<GuideBook />} />
        <Route path="/story" element={<StoryPage />} />
        <Route path="/side-stories" element={<SideStoryPage />} />
        <Route path="/story-branch" element={<StoryBranchPage />} />
        <Route path="/story-branch/major-events" element={<StoryMajorEventsPage />} />
        <Route path="/story-branch/introduction" element={<StoryIntroductionPage />} />
          {/* 添加关卡重定向路由，确保直接访问runtime也能正常加载 */}
          <Route path="/runtime" element={<Home />} />
          {/* 人物关系页面 */}
          <Route path="/character-relationships" element={<CharacterRelationships />} />
          {/* 邮件页面 */}
          <Route 
            path="/mail" 
            element={<MailPage />}
          />
          {/* 特殊关卡战斗页面 */}
          <Route path="/special-level" element={<SpecialLevelBattle />} />
          {/* 新世界页面 */}
          <Route path="/newword" element={<NewWorldPage />} />
          {/* 登录与私人页面 */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/private" element={<RequireAuth><PrivatePage /></RequireAuth>} />
      <Route path="/quotes" element={<FengYanFengYuPage />} />
          {/* 世界观分类页面 */}
          <Route path="/worldview-classification" element={<WorldviewClassificationPage />} />
      </Routes>
      {/* 移除Suspense闭合标签 */}
      
      {/* 音乐播放器组件 - 固定在右下角 */}
      <MusicPlayer />
    </AuthProvider>
    </ThemeProvider>
  );
}

export default App;


