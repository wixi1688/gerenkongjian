import { css } from 'styled-components';

export const specialLevelBattleStyles = css`
  /* 特殊关卡战斗页面样式 */
  .special-level-battle {
    width: 100%;
    min-height: 100vh;
    background-color: #0a0a2a;
    color: #ffffff;
    font-family: 'Arial', sans-serif;
    padding: 20px;
    box-sizing: border-box;
  }

  /* 战斗页面头部 */
  .battle-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 20px;
    background-color: #1a1a4a;
    border-radius: 10px;
    margin-bottom: 20px;
  }

  .battle-header h1 {
    margin: 0;
    color: #ffd700;
    font-size: 24px;
  }

  .back-btn {
    background: none;
    border: none;
    color: #ffffff;
    font-size: 24px;
    cursor: pointer;
    padding: 5px 15px;
    background-color: #2a2a6a;
    border-radius: 5px;
    transition: background-color 0.3s;
  }

  .back-btn:hover {
    background-color: #3a3a7a;
  }

  .turn-status {
    display: flex;
    align-items: center;
  }

  .player-turn {
    background-color: #28a745;
    color: #ffffff;
    padding: 5px 15px;
    border-radius: 20px;
    font-weight: bold;
    animation: pulse 1.5s infinite;
  }

  @keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.7; }
    100% { opacity: 1; }
  }

  /* 队伍选择界面 */
  .team-selection-container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 20px;
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
      transform: translateY(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-in {
    animation: fadeIn 0.5s ease forwards;
  }

  /* 战斗界面 */
  .battle-field {
    max-width: 1000px;
    margin: 0 auto;
  }

  .turn-indicator {
    background-color: #1a1a4a;
    border-radius: 10px;
    padding: 15px;
    text-align: center;
    margin-bottom: 20px;
  }

  .turn-indicator h3 {
    margin: 0;
    color: #ffd700;
    font-size: 20px;
  }

  .turn-indicator p {
    margin: 5px 0 0 0;
    color: #cccccc;
  }

  .battle-area {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #1a1a4a;
    border-radius: 10px;
    padding: 30px;
    margin-bottom: 20px;
  }

  .player-character,
  .enemy-character {
    width: 40%;
    background-color: #2a2a6a;
    border-radius: 10px;
    padding: 20px;
    text-align: center;
  }

  .player-character {
    border: 2px solid #28a745;
  }

  .enemy-character {
    border: 2px solid #dc3545;
  }

  .character-stats h3 {
    margin: 0 0 15px 0;
    color: #ffffff;
    font-size: 18px;
  }

  .hp-bar {
    width: 100%;
    height: 20px;
    background-color: #3a3a7a;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 10px;
  }

  .hp-fill {
    height: 100%;
    background-color: #28a745;
    transition: width 0.3s ease;
  }

  .hp-bar.enemy .hp-fill.enemy {
    background-color: #dc3545;
  }

  .character-stats p {
    margin: 5px 0;
    color: #cccccc;
    font-size: 14px;
  }

  .vs-indicator {
    font-size: 36px;
    font-weight: bold;
    color: #ffd700;
    padding: 0 20px;
  }

  /* 队伍面板 */
  .team-panels {
    margin-bottom: 20px;
  }

  .toggle-team-btn {
    background-color: #007bff;
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    margin-bottom: 10px;
    transition: background-color 0.3s;
  }

  .toggle-team-btn:hover {
    background-color: #0056b3;
  }

  .player-team-panel,
  .enemy-team-panel {
    background-color: #1a1a4a;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 10px;
  }

  .player-team-panel h4,
  .enemy-team-panel h4 {
    margin: 0 0 10px 0;
    color: #ffd700;
  }

  .player-team-panel h4 {
    color: #28a745;
  }

  .enemy-team-panel h4 {
    color: #dc3545;
  }

  .team-members {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
  }

  .team-member {
    background-color: #2a2a6a;
    padding: 8px 12px;
    border-radius: 15px;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 12px;
    border: 1px solid transparent;
  }

  .team-member:hover {
    background-color: #3a3a7a;
  }

  .team-member.active {
    border-color: #ffd700;
    background-color: #4a3a7a;
  }

  .team-member.dead {
    opacity: 0.5;
    text-decoration: line-through;
  }

  .team-member p {
    margin: 2px 0 0 0;
    font-size: 10px;
    color: #cccccc;
  }

  /* 行动按钮 */
  .action-buttons {
    text-align: center;
    margin-bottom: 20px;
  }

  .attack-btn {
    background-color: #dc3545;
    color: #ffffff;
    border: none;
    padding: 12px 40px;
    border-radius: 25px;
    font-size: 18px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s;
  }

  .attack-btn:hover:not(:disabled) {
    background-color: #c82333;
    transform: scale(1.05);
  }

  .attack-btn:disabled {
    background-color: #6c757d;
    cursor: not-allowed;
  }

  /* 战斗日志 */
  .battle-log {
    background-color: #1a1a4a;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 20px;
    max-height: 200px;
    overflow-y: auto;
  }

  .battle-log h4 {
    margin: 0 0 10px 0;
    color: #ffd700;
  }

  .log-content {
    font-size: 14px;
  }

  .log-entry {
    margin-bottom: 5px;
    padding: 5px;
    background-color: #2a2a6a;
    border-radius: 5px;
  }

  .round-indicator {
    color: #ffd700;
    font-weight: bold;
  }

  /* 底部控制按钮 */
  .bottom-controls {
    display: flex;
    justify-content: space-around;
    padding: 20px;
    background-color: #1a1a4a;
    border-radius: 10px;
  }

  .restart-btn,
  .return-button {
    padding: 10px 25px;
    border: none;
    border-radius: 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s;
  }

  .restart-button {
    background-color: #ffc107;
    color: #000000;
  }

  .restart-button:hover {
    background-color: #e0a800;
  }

  .home-btn {
    background-color: #6c757d;
    color: #ffffff;
  }

  .return-button:hover {
    background-color: #5a6268;
  }

  /* 战斗结束界面样式 */
  .battle-end-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
    animation: fadeIn 0.5s ease-in-out;
  }

  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  .battle-end-content {
    background: linear-gradient(135deg, #1a1a4a 0%, #2a2a6a 100%);
    border-radius: 15px;
    padding: 35px;
    text-align: center;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    max-width: 500px;
    width: 90%;
    animation: slideIn 0.5s ease-out;
  }

  @keyframes slideIn {
    from { 
      transform: translateY(-50px); 
      opacity: 0;
    }
    to { 
      transform: translateY(0); 
      opacity: 1;
    }
  }

  .victory-title {
    font-size: 36px;
    margin-bottom: 25px;
    color: #28a745;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
    animation: victoryPulse 1s ease-in-out infinite alternate;
  }

  .defeat-title {
    font-size: 36px;
    margin-bottom: 25px;
    color: #dc3545;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
  }

  @keyframes victoryPulse {
    from { transform: scale(1); }
    to { transform: scale(1.05); }
  }

  .battle-end-content p {
    margin: 0 0 20px 0;
    font-size: 18px;
    color: #cccccc;
  }

  .battle-stats {
    margin: 25px 0;
    padding: 20px;
    background-color: rgba(42, 42, 106, 0.9);
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  }

  .battle-stats h3 {
    margin: 0 0 15px 0;
    color: #ffd700;
  }

  .stat-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 10px 0;
    padding: 8px 0;
    border-bottom: 1px solid #3a3a7a;
    animation: statFadeIn 0.3s ease-out;
  }

  .stat-item:last-child {
    border-bottom: none;
  }

  @keyframes statFadeIn {
    from { opacity: 0; transform: translateX(-20px); }
    to { opacity: 1; transform: translateX(0); }
  }

  .stat-label {
    font-weight: 600;
    color: #cccccc;
    font-size: 15px;
  }

  .stat-value {
    font-weight: bold;
    color: #ffd700;
    font-size: 16px;
  }

  .end-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    margin-top: 30px;
    flex-wrap: wrap;
  }

  .restart-button, .return-button {
    padding: 14px 28px;
    border: none;
    border-radius: 8px;
    font-size: 17px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    min-width: 140px;
    position: relative;
    overflow: hidden;
  }

  .restart-btn {
    background-color: #ffc107;
    color: #000000;
  }

  .restart-btn:hover {
    background-color: #e0a800;
    transform: translateY(-3px);
    box-shadow: 0 6px 16px rgba(255, 193, 7, 0.4);
  }

  .restart-button:active {
    transform: translateY(-1px);
    box-shadow: 0 3px 8px rgba(255, 193, 7, 0.4);
  }

  .home-btn {
    background-color: #6c757d;
    color: #ffffff;
  }

  .home-btn:hover {
    background-color: #5a6268;
    transform: translateY(-3px);
    box-shadow: 0 6px 16px rgba(108, 117, 125, 0.4);
  }

  .return-button:active {
    transform: translateY(-1px);
    box-shadow: 0 3px 8px rgba(108, 117, 125, 0.4);
  }

  /* 按钮点击波纹效果 */
  .restart-button::after, .return-button::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.5);
    transform: translate(-50%, -50%);
    transition: width 0.6s, height 0.6s;
  }

  .restart-button:active::after, .return-button:active::after {
    width: 300px;
    height: 300px;
  }

  /* 响应式设计 */
  @media (max-width: 768px) {
    .battle-area {
      flex-direction: column;
      gap: 20px;
    }
    
    .player-character,
    .enemy-character {
      width: 80%;
    }
    
    .vs-indicator {
      transform: rotate(90deg);
      margin: 20px 0;
    }
    
    .available-characters {
      grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    }
    
    .character-icon {
      width: 60px;
      height: 60px;
    }
    
    .end-buttons {
      flex-direction: column;
    }
  }

  @media (max-width: 480px) {
    .special-level-battle {
      padding: 10px;
    }
    
    .battle-header {
      padding: 10px;
    }
    
    .battle-header h1 {
      font-size: 18px;
    }
    
    .player-character,
    .enemy-character {
      width: 95%;
      padding: 15px;
    }
    
    .available-characters {
      grid-template-columns: repeat(2, 1fr);
    }
    
    .bottom-controls {
      flex-direction: column;
      gap: 10px;
    }
    
    .restart-btn,
    .home-btn {
      width: 100%;
    }
  }
`;
