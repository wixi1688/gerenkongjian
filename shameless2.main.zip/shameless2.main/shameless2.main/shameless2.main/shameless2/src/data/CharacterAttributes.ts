// 角色通用属性类型

export interface CharacterAttributes {
  // 通用属性
  name: string;
  description: string;
  quote?: string;
  rarity: string;
  category: string;
  unlockLevel?: number;

  // 战斗属性
  health: number;
  damage?: number;
  speed?: number;
  armor?: number;

  // 特殊属性
  specialEffect?: string;
  weakness?: string[];
  bestAgainst?: string[];

  // 图片相关
  imageUrl?: string;
}
