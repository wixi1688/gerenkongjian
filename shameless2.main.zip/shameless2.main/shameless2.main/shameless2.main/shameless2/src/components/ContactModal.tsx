import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="bg-gray-900 border-2 border-blue-500 rounded-xl p-6 max-w-md w-full mx-4 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
              aria-label="关闭"
            >
              <i className="fa-solid fa-xmark text-xl"></i>
            </button>
            
            <div className="text-center">
              <div className="text-5xl text-blue-400 mb-6">
                <i className="fa-solid fa-address-book"></i>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">联系方式</h3>
              <div className="text-gray-300 text-lg mb-6 p-4 bg-gray-800/50 rounded-lg border border-blue-900/50">
                <p className="mb-2"><strong className="text-blue-300">联系人：</strong> wixi</p>
                <p><strong className="text-blue-300">联系方式：</strong> zuisuizhe001</p>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onClose}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors"
              >
                我知道了
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
					)}
    </AnimatePresence>
  );
};

export default ContactModal;