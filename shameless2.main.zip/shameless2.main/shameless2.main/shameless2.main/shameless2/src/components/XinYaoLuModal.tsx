import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface XinYaoLuModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const XinYaoLuModal: React.FC<XinYaoLuModalProps> = ({ isOpen, onClose }) => {
  const [currentPage, setCurrentPage] = useState(0);

  const content = [
    {
      title: "心药录",
      text: "世有良药三副：一曰\"看见\"，二曰\"接纳\"，三曰\"同行\"。"
    },
    {
      title: "心药录",
      text: "古医书载：\"心疾者，非器质性伤损，乃神魂游移失所也。\"如人夜行于雾林，手中灯笼忽灭，便觉四野皆虎狼，草木皆鬼魅——实则虎狼鬼魅，皆心生耳。"
    },
    {
      title: "心药录",
      text: "疗愈之始，不在驱散\"鬼魅\"，而在重新点亮灯笼。灯笼为何？曰\"觉察\"。初时微光如豆，仅照见脚下方寸，却足以让人停止奔逃，发现\"虎狼\"原是老树，\"鬼魅\"竟是花影。"
    },
    {
      title: "心药录",
      text: "继而需学\"捧沙\"之术。握沙过紧，沙自指缝流失；握之太松，沙亦随风散去。恰如对待伤痛：抗拒则如紧握，愈痛愈紧；放任则如松手，愈散愈空。唯以掌心承之，知其轻重，感其凉暖，方得平衡。"
    },
    {
      title: "心药录",
      text: "终章归于\"行路\"。不必疾行，无需向导，只携一盏灯，持一捧沙，遇山绕路，逢水架桥。途中或有风雨，灯焰摇曳却不熄；或有颠簸，沙粒增减却不空。行至水穷处，蓦然回首，灯火已照亮来时路，掌心沙竟化为珍珠。"
    },
    {
      title: "心药录",
      text: "此三副药，无君臣佐使，无剂量疗程，唯需\"信\"字为引——信暗夜有尽时，信微光可燎原，信自己终能与那个\"受伤的小孩\"并肩，从故事的这一页，走到下一页。"
    }
  ];

  const handleNextPage = () => {
    if (currentPage < content.length - 1) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="max-w-2xl w-full mx-4"
            onClick={(e) => e.stopPropagation()}
          >
            {/* 心药录弹窗容器 */}
            <div className="border-4 border-gray-800 rounded-3xl overflow-hidden bg-gradient-to-br from-amber-50 to-yellow-100 shadow-2xl">
              {/* 标题区域 */}
              <div className="bg-gradient-to-r from-amber-800 to-amber-700 py-4 px-6 flex justify-between items-center border-b-2 border-amber-900/30">
                <h2 className="text-2xl font-bold text-amber-100 tracking-wide">
                  {content[currentPage]?.title || '心药录'}
                </h2>
                <button
                  onClick={onClose}
                  className="text-amber-100 hover:text-white transition-colors"
                  aria-label="关闭"
                >
                  <i className="fa-solid fa-xmark text-xl"></i>
                </button>
              </div>

              {/* 内容区域 */}
              <div className="p-6 min-h-[200px] max-h-[400px] overflow-y-auto">
                <div className="text-gray-800 leading-relaxed text-lg whitespace-pre-line">
                  {content[currentPage]?.text || ''}
                </div>
              </div>

              {/* 底部导航 */}
              <div className="bg-amber-50 py-4 px-6 border-t-2 border-amber-200 flex justify-between items-center">
                <button
                  onClick={handlePrevPage}
                  disabled={currentPage === 0}
                  className={`px-4 py-2 rounded-lg transition-all duration-300 ${currentPage === 0 ? 'text-gray-400 cursor-not-allowed' : 'bg-amber-700 text-white hover:bg-amber-800'}`}
                >
                  上一页
                </button>
                
                <div className="flex items-center gap-2">
                  {content.map((_, index) => (
                    <div
                      key={index}
                      className={`w-2 h-2 rounded-full ${index === currentPage ? 'bg-amber-700' : 'bg-amber-300'}`}
                    ></div>
                  ))}
                </div>
                
                <button
                  onClick={handleNextPage}
                  disabled={currentPage === content.length - 1}
                  className={`px-4 py-2 rounded-lg transition-all duration-300 ${currentPage === content.length - 1 ? 'text-gray-400 cursor-not-allowed' : 'bg-amber-700 text-white hover:bg-amber-800'}`}
                >
                  下一页
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default XinYaoLuModal;