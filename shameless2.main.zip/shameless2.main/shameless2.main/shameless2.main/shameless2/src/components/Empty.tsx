import React from 'react';
import { motion } from 'framer-motion';

interface EmptyProps {
  loading?: boolean;
  title?: string;
  description?: string;
  icon?: string;
  actionText?: string;
  onAction?: () => void;
}

const Empty: React.FC<EmptyProps> = ({
  loading = false,
  title = '暂无数据',
  description = '暂无相关内容',
  icon = 'fa-box-open',
  actionText,
  onAction,
}) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] p-6 text-center bg-gray-900 rounded-xl">
      {loading ? (
        <motion.div 
          animate={{ rotate: 360 }} 
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="text-gray-400 text-5xl mb-4"
        >
          <i className="fa-solid fa-spinner"></i>
        </motion.div>
      ) : (
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-gray-400 text-5xl mb-4"
        >
          <i className={`fa-solid ${icon}`}></i>
        </motion.div>
      )}
      
      <h3 className="text-xl font-semibold text-gray-300 mb-2">
        {loading ? '加载中...' : title}
      </h3>
      
      <p className="text-gray-400 max-w-md mb-6">
        {loading ? '正在加载数据，请稍候...' : description}
      </p>
      
      {actionText && onAction && (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onAction}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors duration-300"
        >
          {actionText}
        </motion.button>
      )}
    </div>
  );
};

export default Empty;