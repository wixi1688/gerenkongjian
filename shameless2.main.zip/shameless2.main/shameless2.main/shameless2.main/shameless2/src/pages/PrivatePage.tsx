import React from "react";
import { useNavigate } from "react-router-dom";

const PrivatePage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-blue-950 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-gray-900/90 border border-blue-500/30 rounded-2xl p-6 sm:p-8 shadow-xl">
        <div className="grid grid-cols-1 sm:grid-cols-[auto_1fr] gap-6 items-center">
           <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gray-800 border-2 border-blue-500 overflow-hidden flex items-center justify-center">
             <img 
               src="https://lf-code-agent.coze.cn/obj/x-ai-cn/307170232066/attachment/wixi_20251114155009.jpg" 
               alt="用户头像" 
               className="w-full h-full object-cover" 
             />
           </div>
          <div className="text-sm sm:text-base text-white/90 space-y-2">
            <div>身份：管理员</div>
            <div>名字：wixi</div>
            <div className="flex items-center gap-2">痛苦指数：
              <span className="text-yellow-400">☆ ☆ ☆ ☆ ☆</span>
            </div>
          </div>
        </div>

        <div className="mt-6 text-center text-white/90">
          <div className="inline-block w-full max-w-lg border-t border-white/20" />
          <div className="mt-2">亲爱的朋友，欢迎您能来到这里</div>
        </div>

        <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            "私人游戏",
            "丰功伟绩",
            "私人邮箱"
          ].map((t) => (
            <div
              key={t}
              className="h-24 rounded-xl bg-gray-800 border border-gray-700 flex items-center justify-center text-white/90 cursor-pointer select-none [touch-action:manipulation] [will-change:transform,opacity] [transition:transform_400ms_cubic-bezier(0.4,0,0.2,1),opacity_400ms_cubic-bezier(0.4,0,0.2,1)] hover:[transform:translate3d(0,-2px,0)_scale(1.02)]"
            >
              {t}
            </div>
          ))}
        </div>

        <div className="mt-6 h-28 sm:h-40 rounded-2xl bg-gray-800 border border-gray-700" />

        <div className="mt-6 flex justify-between">
          <button
            onClick={() => navigate(-1)}
            className="px-4 py-2 bg-gray-700 text-white rounded-md [touch-action:manipulation] [will-change:transform,opacity] [transition:transform_300ms_cubic-bezier(0.4,0,0.2,1)] active:[transform:translate3d(-2px,0,0)]"
          >
            返回
          </button>
          <button
            onClick={() => navigate("/")}
            className="px-4 py-2 bg-blue-600 text-white rounded-md [touch-action:manipulation] [will-change:transform,opacity] [transition:transform_300ms_cubic-bezier(0.4,0,0.2,1)] active:[transform:translate3d(2px,0,0)]"
          >
            主页
          </button>
        </div>
      </div>
    </div>
  );
};

export default PrivatePage;
