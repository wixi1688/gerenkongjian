import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/authContext";
import { AnimatePresence, motion } from "framer-motion";

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { login, csrfToken, refreshCsrf } = useAuth();
  const [account, setAccount] = useState("");
  const [password, setPassword] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showDemoCredentials, setShowDemoCredentials] = useState(false);
  // 控制错误弹窗显示的状态
  const [showErrorModal, setShowErrorModal] = useState(false);
  const isAccountValid = useMemo(() => account.trim().length > 0, [account]);
  const isPasswordValid = useMemo(() => password.trim().length > 0, [password]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!csrfToken) {
      setError("安全校验失败，请重试");
      try { refreshCsrf(); } catch {}
      return;
    }
    const acct = account.trim().replace(/[^\w-]/g, "");
    const pwd = password.trim();
    if (!acct || !pwd) {
      setError("请输入完整的账号与密码");
      return;
    }
    if (acct === "wixi" && pwd === "wixi") {
      setError(null);
      login("wixi");
      setLoading(true);
      const duration = 1000 + Math.floor(Math.random() * 1000);
      window.setTimeout(() => {
        window.history.pushState(null, "", "/private");
        navigate("/private", { replace: true });
      }, duration);
      return;
    }
    // 无论输错多少次，都只显示错误弹窗，不再锁定账号
    setError("账号或密码错误");
    setShowErrorModal(true);
  };

  // 新增：关闭错误弹窗的函数
  const handleCloseErrorModal = () => {
    setShowErrorModal(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-blue-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm sm:max-w-md bg-gray-900/90 border border-blue-500/30 rounded-2xl p-6 sm:p-8 shadow-xl" aria-busy={loading}>
        <div className="flex flex-col items-center mb-6">
          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gray-800 border-2 border-blue-500 flex items-center justify-center overflow-hidden">
            <img 
              src={account.trim().toLowerCase() === "wixi" 
                ? "https://lf-code-agent.coze.cn/obj/x-ai-cn/307170232066/attachment/wixi_20251114155603.jpg" 
                : "https://lf-code-agent.coze.cn/obj/x-ai-cn/307170232066/attachment/时裂灵汐_20251114155705.jpg"} 
              alt="用户头像" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4" aria-describedby={error ? 'login-error' : undefined}>
          <label htmlFor="login-account" className="text-white/90 text-sm sm:text-base">账号名字：</label>
          <input
            id="login-account"
            placeholder="请输入账号"
            value={account}
            onChange={(e) => setAccount(e.target.value)}
            disabled={loading}
            aria-invalid={!isAccountValid}
            className="w-full px-4 py-2 rounded-md bg-gray-800 text-white placeholder-gray-400 outline-none border border-transparent focus:border-blue-500 [transition:border-color_300ms_cubic-bezier(0.4,0,0.2,1)]"
          />

          <label htmlFor="login-password" className="text-white/90 text-sm sm:text-base">账号密码：</label>
          <div className="relative">
            <input
              id="login-password"
              placeholder="请输入密码"
              type={showPwd ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
              aria-invalid={!isPasswordValid}
              className="w-full px-4 py-2 rounded-md bg-gray-800 text-white placeholder-gray-400 outline-none border border-transparent focus:border-blue-500 [transition:border-color_300ms_cubic-bezier(0.4,0,0.2,1)]"
            />
            <button
              type="button"
              onClick={() => setShowPwd((v) => !v)}
              aria-pressed={showPwd}
              aria-label={showPwd ? '隐藏密码' : '显示密码'}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-blue-400 text-sm cursor-pointer select-none [touch-action:manipulation] [will-change:transform,opacity] [transition:transform_300ms_cubic-bezier(0.4,0,0.2,1)] active:[transform:scale(0.95)]"
            >
              {showPwd ? "隐藏" : "显示"}
            </button>
          </div>

          <button 
            onClick={() => setShowDemoCredentials(!showDemoCredentials)}
            className="flex items-center gap-2 text-gray-300 text-xs hover:text-blue-400 transition-colors duration-200 group"
            aria-expanded={showDemoCredentials}
            aria-controls="demo-credentials"
          >
            <div className={`w-3 h-3 rounded-full ${showDemoCredentials ? 'bg-blue-500' : 'bg-gray-600'} border ${showDemoCredentials ? 'border-blue-400' : 'border-gray-500'} group-hover:scale-110 transition-all duration-300`} />
            <span>点击查看账号密码</span>
          </button>
          
          <AnimatePresence>
            {showDemoCredentials && (
              <motion.div
                id="demo-credentials"
                initial={{ opacity: 0, y: -10, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="mt-2 p-3 bg-gray-800/80 border border-blue-500/30 rounded-lg text-xs"
              >
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-400">示例账号：</span>
                  <span className="text-blue-300 font-mono">随便输</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">示例密码：</span>
                  <span className="text-blue-300 font-mono">随便输</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 bg-blue-600 text-white rounded-full py-2 sm:py-3 [touch-action:manipulation] [will-change:transform,opacity] [transition:transform_400ms_cubic-bezier(0.4,0,0.2,1),opacity_400ms_cubic-bezier(0.4,0,0.2,1)] active:[transform:scale(0.97)] disabled:opacity-50"
          >
            确认
          </button>

          <div id="login-error" role="alert" aria-live="polite" className={error ? "mt-2 text-red-500 text-sm" : "hidden"}>{error || ""}</div>
        </form>

        <button
          onClick={() => navigate(-1)}
          className="mt-6 text-gray-300 text-sm [touch-action:manipulation] [will-change:transform,opacity] [transition:transform_300ms_cubic-bezier(0.4,0,0.2,1)] active:[transform:translate3d(-2px,0,0)]"
        >
          返回
        </button>
      </div>

      {loading && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="w-16 h-16 rounded-full border-4 border-blue-500 border-t-transparent animate-spin" />
        </div>
      )}

      {/* 新增：错误弹窗组件 */}
      <AnimatePresence>
        {showErrorModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50"
            onClick={handleCloseErrorModal}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0, y: -20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: 20 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="bg-red-900/90 border-2 border-red-500 rounded-2xl p-6 max-w-md w-full mx-4 relative shadow-2xl shadow-red-900/30"
              onClick={(e) => e.stopPropagation()}
            >
              {/* 警告图标 */}
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.1, type: "spring", stiffness: 400 }}
                className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-red-600 rounded-full p-4 border-4 border-red-800 shadow-lg"
              >
                <i className="fa-solid fa-triangle-exclamation text-white text-2xl"></i>
              </motion.div>
              
              {/* 弹窗内容 */}
              <div className="text-center mt-8">
                <h3 className="text-2xl font-bold text-white mb-4 animate-pulse">警告！</h3>
                <p className="text-xl text-red-200 mb-6 font-medium">
                  输你**，快离开，别逼我自毁程序
                </p>
                
                {/* 动画文字效果 */}
                <motion.div
                  className="text-red-300 text-sm mb-6"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  <motion.span
                    animate={{ opacity: [1, 0.7, 1] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    系统正在监控你的行为...
                  </motion.span>
                </motion.div>
                
                {/* 关闭按钮 */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleCloseErrorModal}
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-full font-bold transition-colors duration-300 shadow-lg"
                >
                  我知道了
                </motion.button>
              </div>
              
              {/* 装饰效果 */}
              <motion.div
                className="absolute -bottom-8 -right-8 w-32 h-32 bg-red-500/30 rounded-full blur-3xl"
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3]
                }}
                transition={{ duration: 3, repeat: Infinity }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default LoginPage;
