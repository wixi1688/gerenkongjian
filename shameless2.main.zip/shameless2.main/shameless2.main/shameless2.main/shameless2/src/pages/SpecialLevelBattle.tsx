import React, { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { PLANTS_CONFIG, ZOMBIES_CONFIG, plantImages } from "../data/gameData";
import { PlantType, ZombieType, GameStatus } from "../data/gameData";

interface BattleCharacter {
    id: string;
    name: string;
    hp: number;
    maxHp: number;
    atk: number;
    isAlive: boolean;
    imageUrl?: string;
    isSelected?: boolean;
}

interface BattleLogEntry {
    round: number;
    content: string;
}

interface TurnState {
    current: "player" | "enemy";
    roundNumber: number;
}

const SpecialLevelBattle: React.FC = () => {
    const navigate = useNavigate();
    const logRef = useRef<HTMLDivElement>(null);
    const startTimeRef = useRef<number>(0);
    const [gameStatus, setGameStatus] = useState<GameStatus>("ready");
    const [selectedPlants, setSelectedPlants] = useState<PlantType[]>([]);
    const [playerTeam, setPlayerTeam] = useState<BattleCharacter[]>([]);
    const [enemyTeam, setEnemyTeam] = useState<BattleCharacter[]>([]);
    const [currentPlayer, setCurrentPlayer] = useState<BattleCharacter | null>(null);
    const [currentEnemy, setCurrentEnemy] = useState<BattleCharacter | null>(null);

    const [turnState, setTurnState] = useState<TurnState>({
        current: "player",
        roundNumber: 1
    });

    const [battleLog, setBattleLog] = useState<BattleLogEntry[]>([]);
    const [showTeamSelection, setShowTeamSelection] = useState(true);
    const [showBattleEnd, setShowBattleEnd] = useState(false);
    const [battleResult, setBattleResult] = useState<"victory" | "defeat">("victory");
    const [showTeamPanel, setShowTeamPanel] = useState(false);
    const [autoAttack, setAutoAttack] = useState(false);
    const [attackIntervalMs, setAttackIntervalMs] = useState(500);
    const autoTimerRef = useRef<number | null>(null);
    const [isNavigating, setIsNavigating] = useState(false);
    const hpAnimFlagRef = useRef<{ playerHp?: number; enemyHp?: number }>({});
    const [isSkipping, setIsSkipping] = useState(false);
    const skipFlagRef = useRef<boolean>(false);
    const navDebounceRef = useRef<boolean>(false);

    const [combatStats, setCombatStats] = useState({
        totalDamageDealt: 0,
        totalDamageTaken: 0,
        turnsUsed: 0,
        battleDuration: 0
    });

    const availablePlants = useMemo(() => Object.keys(PLANTS_CONFIG) as PlantType[], []);
    const availableZombies = useMemo(() => Object.keys(ZOMBIES_CONFIG) as ZombieType[], []);

    const validateCharacterStats = useCallback((character: any) => {
        const health = Math.max(100, Math.min(999999, character.health || 100));
        const damage = Math.max(1, Math.min(9999, character.damage || 10));

        return {
            health,
            damage
        };
    }, []);

    const selectPlant = useCallback((plantType: PlantType) => {
        if (selectedPlants.length < 6 && !selectedPlants.includes(plantType)) {
            setSelectedPlants(prev => [...prev, plantType]);
        } else if (selectedPlants.includes(plantType)) {
            setSelectedPlants(prev => prev.filter(p => p !== plantType));
        }
    }, [selectedPlants]);

    const handleDragStart = useCallback((e: React.DragEvent, plantType: PlantType) => {
        e.dataTransfer.setData("plantType", plantType);
    }, []);

    const handleDragOver = useCallback((e: React.DragEvent) => {
        e.preventDefault();
    }, []);

    const handleDrop = useCallback((e: React.DragEvent, targetIndex: number) => {
        e.preventDefault();
        const draggedPlantType = e.dataTransfer.getData("plantType") as PlantType;
        const draggedIndex = selectedPlants.indexOf(draggedPlantType);

        if (draggedIndex !== -1 && draggedIndex !== targetIndex) {
            const newSelectedPlants = [...selectedPlants];
            newSelectedPlants.splice(draggedIndex, 1);
            newSelectedPlants.splice(targetIndex, 0, draggedPlantType);
            setSelectedPlants(newSelectedPlants);
        }
    }, [selectedPlants]);

    const startBattle = useCallback(() => {
        if (selectedPlants.length !== 6)
            return;

        startTimeRef.current = Date.now();

        const newPlayerTeam = selectedPlants.map(plantType => {
            const plant = PLANTS_CONFIG[plantType];
            const validatedStats = validateCharacterStats(plant);

            return {
                id: plantType,
                name: plant.name,
                hp: validatedStats.health,
                maxHp: validatedStats.health,
                atk: validatedStats.damage,
                isAlive: true,
                imageUrl: plant.imageUrl || `https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Cartoon%20fantasy%20plant%20character%20${encodeURIComponent(plant.name)}`
            };
        });

        const randomZombies = availableZombies.sort(() => Math.random() - 0.5).slice(0, 6);

        const newEnemyTeam = randomZombies.map(zombieType => {
            const zombie = ZOMBIES_CONFIG[zombieType];
            const validatedStats = validateCharacterStats(zombie);

            return {
                id: zombieType,
                name: zombie.name,
                hp: validatedStats.health,
                maxHp: validatedStats.health,
                atk: validatedStats.damage,
                isAlive: true,
                imageUrl: zombie.imageUrl || `https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Cartoon%20fantasy%20zombie%20character%20${encodeURIComponent(zombie.name)}`
            };
        });

        setPlayerTeam(newPlayerTeam);
        setEnemyTeam(newEnemyTeam);
        setCurrentPlayer(newPlayerTeam[0]);
        setCurrentEnemy(newEnemyTeam[0]);
        setShowTeamSelection(false);
        setGameStatus("playing");

        setCombatStats({
            totalDamageDealt: 0,
            totalDamageTaken: 0,
            turnsUsed: 0,
            battleDuration: 0
        });

        addBattleLog(`战斗开始！玩家派出了${newPlayerTeam[0].name}，敌人派出了${newEnemyTeam[0].name}。`);
    }, [selectedPlants, availableZombies, validateCharacterStats]);

    const addBattleLog = useCallback((content: string) => {
        setBattleLog(prev => {
            const newLog = [...prev, {
                round: turnState.roundNumber,
                content
            }];

            return newLog.slice(-50);
        });

        setTimeout(() => {
            if (logRef.current) {
                logRef.current.scrollTop = logRef.current.scrollHeight;
            }
        }, 0);
    }, [turnState.roundNumber]);

    const attack = useCallback(() => {
        if (!currentPlayer || !currentEnemy || gameStatus !== "playing")
            return;

        const playerDamage = currentPlayer.atk;
        const newEnemyHp = Math.max(0, currentEnemy.hp - playerDamage);
        const enemyDefeated = newEnemyHp === 0;

        setCombatStats(prev => ({
            ...prev,
            totalDamageDealt: prev.totalDamageDealt + playerDamage,
            turnsUsed: prev.turnsUsed + 1
        }));

        const updatedEnemy = {
            ...currentEnemy,
            hp: newEnemyHp,
            isAlive: !enemyDefeated
        };

        addBattleLog(`${currentPlayer.name}对${currentEnemy.name}造成了${playerDamage}点伤害！`);
        setCurrentEnemy(updatedEnemy);
        setEnemyTeam(prev => prev.map(e => e.id === updatedEnemy.id ? updatedEnemy : e));

        if (enemyDefeated) {
            addBattleLog(`${currentEnemy.name}被击败了！`);
            const remainingEnemies = enemyTeam.filter(e => e.id !== updatedEnemy.id && e.isAlive);

            if (remainingEnemies.length === 0) {
                const battleDuration = Math.floor((Date.now() - startTimeRef.current) / 1000);

                setCombatStats(prev => ({
                    ...prev,
                    battleDuration
                }));

                setBattleResult("victory");
                setGameStatus("victory");
                setShowBattleEnd(true);
                addBattleLog("恭喜！玩家获胜！");
                return;
            }

            const nextEnemy = remainingEnemies[0];
            setCurrentEnemy(nextEnemy);
            addBattleLog(`敌人派出了${nextEnemy.name}！`);

            setTimeout(() => {
                enemyTurn(nextEnemy, currentPlayer);
            }, 1500);
        } else {
            setTimeout(() => {
                enemyTurn(updatedEnemy, currentPlayer);
            }, 1500);
        }
    }, [currentPlayer, currentEnemy, gameStatus, enemyTeam, addBattleLog]);

    const enemyTurn = useCallback((enemy: BattleCharacter, player: BattleCharacter) => {
        if (skipFlagRef.current) return;
        const enemyDamage = enemy.atk;
        const newPlayerHp = Math.max(0, player.hp - enemyDamage);
        const playerDefeated = newPlayerHp === 0;

        setCombatStats(prev => ({
            ...prev,
            totalDamageTaken: prev.totalDamageTaken + enemyDamage
        }));

        const updatedPlayer = {
            ...player,
            hp: newPlayerHp,
            isAlive: !playerDefeated
        };

        addBattleLog(`${enemy.name}对${player.name}造成了${enemyDamage}点伤害！`);
        setCurrentPlayer(updatedPlayer);
        setPlayerTeam(prev => prev.map(p => p.id === updatedPlayer.id ? updatedPlayer : p));

        if (playerDefeated) {
            addBattleLog(`${player.name}被击败了！`);
            const remainingPlayers = playerTeam.filter(p => p.id !== updatedPlayer.id && p.isAlive);

            if (remainingPlayers.length === 0) {
                const battleDuration = Math.floor((Date.now() - startTimeRef.current) / 1000);

                setCombatStats(prev => ({
                    ...prev,
                    battleDuration
                }));

                setBattleResult("defeat");
                setGameStatus("gameover");
                setShowBattleEnd(true);
                addBattleLog("很遗憾！玩家失败了！");
                return;
            }

            const nextPlayer = remainingPlayers[0];
            setCurrentPlayer(nextPlayer);
            addBattleLog(`玩家派出了${nextPlayer.name}！`);
        }

        setTurnState(prev => ({
            current: "player",
            roundNumber: prev.roundNumber + 1
        }));
    }, [playerTeam, addBattleLog]);

    const skipBattle = useCallback(() => {
        if (gameStatus !== "playing") return;
        setIsSkipping(true);
        skipFlagRef.current = true;
        if (autoTimerRef.current !== null) {
            clearInterval(autoTimerRef.current);
            autoTimerRef.current = null;
        }
        setAutoAttack(false);

        setTimeout(() => {
            try {
                const pAll = playerTeam.map(p => ({ ...p }));
                const eAll = enemyTeam.map(e => ({ ...e }));
                const pAlive = pAll.filter(p => p.isAlive);
                const eAlive = eAll.filter(e => e.isAlive);

                const orderWithCurrent = (list: BattleCharacter[], current: BattleCharacter | null) => {
                    if (!current) return list;
                    const idx = list.findIndex(x => x.id === current.id);
                    if (idx <= 0) return list;
                    const copy = [...list];
                    const [cur] = copy.splice(idx, 1);
                    copy.unshift(cur);
                    return copy;
                };

                const pQueue = orderWithCurrent(pAlive, currentPlayer);
                const eQueue = orderWithCurrent(eAlive, currentEnemy);

                let pIndex = 0;
                let eIndex = 0;
                let totalDealt = 0;
                let totalTaken = 0;
                let turnsUsed = combatStats.turnsUsed;
                let roundNum = turnState.roundNumber;

                while (pIndex < pQueue.length && eIndex < eQueue.length) {
                    const p = pQueue[pIndex];
                    const e = eQueue[eIndex];
                    const eHp = Math.max(0, e.hp - p.atk);
                    totalDealt += p.atk;
                    e.hp = eHp;
                    e.isAlive = eHp > 0;
                    turnsUsed += 1;
                    roundNum += 1;
                    if (!e.isAlive) {
                        eIndex += 1;
                        continue;
                    }
                    const pHp = Math.max(0, p.hp - e.atk);
                    totalTaken += e.atk;
                    p.hp = pHp;
                    p.isAlive = pHp > 0;
                    if (!p.isAlive) {
                        pIndex += 1;
                    }
                }

                const battleDuration = Math.floor((Date.now() - startTimeRef.current) / 1000);
                const victory = eQueue.slice(eIndex).length === 0;

                setCombatStats(prev => ({
                    ...prev,
                    totalDamageDealt: prev.totalDamageDealt + totalDealt,
                    totalDamageTaken: prev.totalDamageTaken + totalTaken,
                    turnsUsed,
                    battleDuration
                }));

                const pUpdated = pAll.map(p => ({ ...p }));
                const eUpdated = eAll.map(e => ({ ...e }));
                setPlayerTeam(pUpdated);
                setEnemyTeam(eUpdated);

                const nextP = pUpdated.find(p => p.isAlive) || null;
                const nextE = eUpdated.find(e => e.isAlive) || null;
                setCurrentPlayer(nextP);
                setCurrentEnemy(nextE);
                setTurnState({ current: "player", roundNumber: roundNum });

                setBattleResult(victory ? "victory" : "defeat");
                setGameStatus(victory ? "victory" : "gameover");
                setShowBattleEnd(true);
                addBattleLog(victory ? "战斗已跳过，直接结算：胜利" : "战斗已跳过，直接结算：失败");
            } catch (e) {
                addBattleLog("跳过战斗失败");
                skipFlagRef.current = false;
            } finally {
                setIsSkipping(false);
            }
        }, 50);
    }, [gameStatus, playerTeam, enemyTeam, currentPlayer, currentEnemy, combatStats.turnsUsed, turnState.roundNumber, addBattleLog]);

    useEffect(() => {
        if (currentPlayer?.hp !== undefined && hpAnimFlagRef.current.playerHp !== currentPlayer.hp) {
            hpAnimFlagRef.current.playerHp = currentPlayer.hp;
        }
    }, [currentPlayer?.hp]);

    useEffect(() => {
        if (currentEnemy?.hp !== undefined && hpAnimFlagRef.current.enemyHp !== currentEnemy.hp) {
            hpAnimFlagRef.current.enemyHp = currentEnemy.hp;
        }
    }, [currentEnemy?.hp]);

    useEffect(() => {
        if (!autoAttack) {
            if (autoTimerRef.current !== null) {
                clearInterval(autoTimerRef.current);
                autoTimerRef.current = null;
            }
            return;
        }

        if (autoTimerRef.current !== null) {
            clearInterval(autoTimerRef.current);
        }

        autoTimerRef.current = window.setInterval(() => {
            try {
                if (gameStatus !== "playing") return;
                if (turnState.current !== "player") return;
                if (!currentPlayer || !currentEnemy) return;
                attack();
            } catch (e) {
                addBattleLog("自动攻击异常");
                setAutoAttack(false);
            }
        }, attackIntervalMs);

        return () => {
            if (autoTimerRef.current !== null) {
                clearInterval(autoTimerRef.current);
                autoTimerRef.current = null;
            }
        };
    }, [autoAttack, attackIntervalMs, gameStatus, turnState.current, currentPlayer, currentEnemy, attack, addBattleLog]);

    useEffect(() => {
        if (gameStatus !== "playing" && autoAttack) {
            setAutoAttack(false);
        }
    }, [gameStatus]);

    const switchCharacter = (character: BattleCharacter) => {
        if (!character.isAlive || gameStatus !== "playing" || turnState.current !== "player")
            return;

        setCurrentPlayer(character);
        addBattleLog(`玩家切换到了${character.name}！`);
    };

    const restartBattle = () => {
        if (autoTimerRef.current !== null) {
            clearInterval(autoTimerRef.current);
            autoTimerRef.current = null;
        }
        setAutoAttack(false);
        setGameStatus("ready");
        setSelectedPlants([]);
        setPlayerTeam([]);
        setEnemyTeam([]);
        setCurrentPlayer(null);
        setCurrentEnemy(null);

        setTurnState({
            current: "player",
            roundNumber: 1
        });

        setBattleLog([]);
        setShowTeamSelection(true);
        setShowBattleEnd(false);
    };

    const returnToHome = () => {
        if (navDebounceRef.current || isNavigating || isSkipping) return;
        navDebounceRef.current = true;
        setTimeout(() => { navDebounceRef.current = false; }, 300);

        const hasUnsaved = gameStatus === "playing" && !showBattleEnd;
        if (hasUnsaved) {
            const ok = window.confirm("当前战斗尚未结算，确认返回主页？");
            if (!ok) return;
        }

        if (autoTimerRef.current !== null) {
            clearInterval(autoTimerRef.current);
            autoTimerRef.current = null;
        }
        setAutoAttack(false);
        setIsNavigating(true);
        setTimeout(() => {
            navigate("/");
        }, 100);
    };

    const renderTeamSelection = () => <div className="w-full max-w-5xl mx-auto">
        {}
        <div
            className="bg-gradient-to-r from-green-900/50 to-blue-900/50 border border-green-800 rounded-xl p-4 mb-6">
            <div className="flex justify-between items-center">
                <div className="flex items-center">
                    <i className="fa-solid fa-seedling text-green-400 mr-2"></i>
                    <span className="text-white font-medium">已选择 {selectedPlants.length}种植物</span>
                </div>
                <div
                    className={`text-sm font-medium px-3 py-1 rounded-full ${selectedPlants.length === 6 ? "bg-green-900/50 text-green-400" : "bg-yellow-900/50 text-yellow-400"}`}>
                    {selectedPlants.length === 6 ? "已选择 6 种植物" : `还需选择 ${6 - selectedPlants.length} 种植物`}
                </div>
            </div>
            {}
            <div className="w-full bg-gray-700 rounded-full h-2 mt-3">
                <div
                    className={`h-2 rounded-full transition-all duration-500 ${selectedPlants.length === 6 ? "bg-green-500" : "bg-yellow-500"}`}
                    style={{
                        width: `${selectedPlants.length / 6 * 100}%`
                    }}></div>
            </div>
            {}
            <div className="text-xs text-gray-300 mt-2 flex justify-between">
                <span>至少选择1种植物</span>
                <span>最多选择6种植物</span>
            </div>
        </div>
        {}
        {selectedPlants.length > 0 && <div className="mb-6">
            <div className="flex justify-between items-center mb-3">
                <h3 className="text-lg font-bold text-white flex items-center">
                    <i className="fa-solid fa-check-circle text-green-400 mr-2"></i>已选择的植物
                                </h3>
            </div>
            <div className="flex flex-wrap gap-2">
                {selectedPlants.map((plantType, index) => {
                    const plant = PLANTS_CONFIG[plantType];

                    return (
                        <div
                            key={plantType}
                            className="flex items-center bg-gray-800 rounded-full px-3 py-1 animate-fade-in"
                            draggable={true}
                            onDragStart={e => handleDragStart(e, plantType)}
                            onDragOver={handleDragOver}
                            onDrop={e => handleDrop(e, index)}
                            style={{
                                animationDelay: `${index * 100}ms`
                            }}>
                            <img
                                src={plantImages[plantType]}
                                alt={plant.name}
                                className="w-6 h-6 rounded-full mr-2 object-cover" />
                            <span className="text-white text-sm">{plant.name}</span>
                            <button
                                onClick={e => {
                                    e.stopPropagation();
                                    selectPlant(plantType);
                                }}
                                className="ml-1 text-gray-400 hover:text-red-400 transition-colors duration-200">
                                <i className="fa-solid fa-times-circle"></i>
                            </button>
                        </div>
                    );
                })}
            </div>
        </div>}
        {}
        <div className="mb-8">
            <h3 className="text-lg font-bold text-white flex items-center mb-4">
                <i className="fa-solid fa-puzzle-piece text-blue-400 mr-2"></i>可用植物
                        </h3>
            <div
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {availablePlants.map(plantType => {
                    const plant = PLANTS_CONFIG[plantType];
                    const isSelected = selectedPlants.includes(plantType);

                    return (
                        <div
                            key={plantType}
                            className={`bg-gradient-to-br ${isSelected ? "from-green-900/50 to-green-800/20" : "from-gray-900/50 to-gray-800/20"} rounded-xl overflow-hidden shadow-lg border ${isSelected ? "border-green-500" : "border-gray-700"} flex flex-col h-full transition-all duration-300 hover:scale-103 hover:shadow-[0_20px_25px_-5px_rgba(34,139,34,0.3)] hover:z-10 ${selectedPlants.length >= 6 && !isSelected ? "opacity-60 cursor-not-allowed" : ""}`}
                            onClick={() => (selectedPlants.length < 6 || isSelected) && selectPlant(plantType)}
                            draggable={true}
                            onDragStart={e => handleDragStart(e, plantType)}>
                            <div className="h-28 overflow-hidden relative">
                                <img
                                    src={plantImages[plantType]}
                                    alt={plant.name}
                                    className="w-full h-full object-cover object-center transform hover:scale-110 transition-transform duration-700"
                                    loading="lazy" />
                                {isSelected && <div
                                    className="absolute top-2 left-2 bg-green-600 text-white text-xs font-bold px-2 py-1 rounded-full">已选择
                                                        </div>}
                                <div
                                    className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-gray-900 to-transparent"></div>
                            </div>
                            <div className="p-3 flex-grow flex flex-col">
                                <h3 className="text-base font-bold text-white mb-1">{plant.name}</h3>
                                <div className="grid grid-cols-2 gap-1 text-xs mt-auto">
                                    <div className="bg-gray-800/80 p-1.5 rounded-lg">
                                        <span className="text-gray-400 block">攻击力</span>
                                        <span className="font-bold text-white">{plant.damage || 0}</span>
                                    </div>
                                    <div className="bg-gray-800/80 p-1.5 rounded-lg">
                                        <span className="text-gray-400 block">生命值</span>
                                        <span className="font-bold text-white">{plant.health}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
        {}
        <button
            onClick={startBattle}
            disabled={selectedPlants.length !== 6}
            className={`w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white font-bold py-4 rounded-xl transition-all duration-300 shadow-lg mb-8 ${selectedPlants.length !== 6 ? "opacity-50 cursor-not-allowed" : "hover:shadow-green-500/30"}`}>
            <div className="flex items-center justify-center">
                <i className="fa-solid fa-play-circle mr-2 text-xl"></i>确认选择并开始战斗
                        </div>
        </button>
    </div>;

    const renderBattleField = () => <div className="w-full max-w-5xl mx-auto px-4 py-6">
        {}
        <div
            className="glassmorphism p-4 rounded-xl text-center mb-6 transition-all duration-500 animate-pulse">
            <h3
                className={`text-xl font-bold mb-1 ${turnState.current === "player" ? "text-green-400" : "text-red-400"}`}>
                {turnState.current === "player" ? "轮到你攻击！" : "敌人回合..."}
            </h3>
            <p className="text-gray-300">第{turnState.roundNumber}回合</p>
        </div>
        {}
        <div className="glassmorphism p-6 rounded-xl mb-6">
            <div className="flex justify-between items-center">
                {}
                <div
                    className="w-1/2 p-4 glassmorphism bg-gradient-to-br from-blue-900/40 to-blue-800/20 border border-blue-500/30 rounded-lg transform transition-all duration-300 hover:scale-[1.02]">
                    <div className="flex items-center justify-between mb-3">
                        <h3 className="text-xl font-bold text-white">{currentPlayer?.name || ""}</h3>
                        <div
                            className="text-sm font-medium px-3 py-1 bg-blue-900/50 text-blue-400 rounded-full">我方角色
                                          </div>
                    </div>
                    {}
                    <div className="flex justify-center mb-3">
                        <div
                            className="w-28 h-28 rounded-full overflow-hidden border-2 border-blue-400 bg-blue-800/30 flex items-center justify-center shadow-lg shadow-blue-500/20">
                            {currentPlayer?.imageUrl ? <img
                                src="https://space-static.coze.site/coze_space/7561212695857447202/upload/%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE2025-11-10114800_220x219.png?sign=1765338513-3d902b30f6-0-9f4c01b074d8e74cca532200f10c4198cd62371120ddc2f8b13f66377414afd4"
                                alt={currentPlayer.name}
                                className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                                loading="lazy"
                                onError={e => {
                                    const target = e.target as HTMLImageElement;
                                    target.style.display = "none";
                                    const iconElement = target.nextElementSibling as HTMLElement;

                                    if (iconElement)
                                        iconElement.style.display = "block";
                                }} /> : <i className="fas fa-seedling text-5xl text-blue-400"></i>}
                            {}
                            <i className="fas fa-seedling text-5xl text-blue-400 hidden absolute"></i>
                        </div>
                    </div>
                    {}
                        <div className="w-full mb-2">
                            <div className="flex justify-between mb-1">
                                <span className="text-gray-300 text-sm">生命值</span>
                                <span className={`text-white font-medium ${currentPlayer && (currentPlayer.hp / currentPlayer.maxHp) <= 0.2 ? "hp-warning-blink" : ""}`}>
                                    {(currentPlayer?.hp || 0).toLocaleString()}/ {(currentPlayer?.maxHp || 0).toLocaleString()}
                                </span>
                            </div>
                            <div className="bg-gray-700/70 rounded-full h-3 overflow-hidden">
                                <div
                                    className={`h-full transition-all duration-500 ${currentPlayer && (currentPlayer.hp / currentPlayer.maxHp) > 0.5 ? "bg-gradient-to-r from-green-500 to-green-400" : currentPlayer && (currentPlayer.hp / currentPlayer.maxHp) > 0.2 ? "bg-gradient-to-r from-yellow-500 to-yellow-400" : "bg-gradient-to-r from-red-500 to-red-400 hp-warning-blink"}`}
                                    style={{
                                        width: `${currentPlayer ? currentPlayer.hp / currentPlayer.maxHp * 100 : 0}%`
                                    }}></div>
                            </div>
                        </div>
                    {}
                    <div className="flex items-center mt-2">
                        <i className="fas fa-crosshairs text-blue-400 mr-2"></i>
                        <span className="text-gray-300">攻击力: <span className="text-white font-medium">{(currentPlayer?.atk || 0).toLocaleString()}</span></span>
                    </div>
                </div>
                {}
                <div className="vs-indicator px-4 flex-shrink-0">
                    <span className="text-4xl font-bold text-yellow-400">VS</span>
                </div>
                {}
                <div
                    className="w-1/2 p-4 glassmorphism bg-gradient-to-br from-red-900/40 to-red-800/20 border border-red-500/30 rounded-lg transform transition-all duration-300 hover:scale-[1.02]">
                    <div className="flex items-center justify-between mb-3">
                        <h3 className="text-xl font-bold text-white">{currentEnemy?.name || ""}</h3>
                        <div
                            className="text-sm font-medium px-3 py-1 bg-red-900/50 text-red-400 rounded-full">敌方角色
                                          </div>
                    </div>
                    {}
                    <div className="flex justify-center mb-3">
                        <div
                            className="w-28 h-28 rounded-full overflow-hidden border-2 border-red-400 bg-red-800/30 flex items-center justify-center shadow-lg shadow-red-500/20 relative">
                            {currentEnemy?.imageUrl ? <img
                                src="https://space-static.coze.site/coze_space/7561212695857447202/upload/%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE2025-11-10114808_252x240.png?sign=1765338521-f87901aece-0-7dfe80a6b789f69b57f62bfd3d64e046f8857f375bf9dd97b8d4ae1ef67c46a5"
                                alt={currentEnemy.name}
                                className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                                loading="lazy"
                                onError={e => {
                                    const target = e.target as HTMLImageElement;
                                    target.style.display = "none";
                                    const iconElement = target.nextElementSibling as HTMLElement;

                                    if (iconElement)
                                        iconElement.style.display = "block";
                                }} /> : <i className="fas fa-skull text-5xl text-red-400"></i>}
                            {}
                            <i className="fas fa-skull text-5xl text-red-400 hidden absolute"></i>
                        </div>
                    </div>
                    {}
                        <div className="w-full mb-2">
                            <div className="flex justify-between mb-1">
                                <span className="text-gray-300 text-sm">生命值</span>
                                <span className={`text-white font-medium ${currentEnemy && (currentEnemy.hp / currentEnemy.maxHp) <= 0.2 ? "hp-warning-blink" : ""}`}>
                                    {(currentEnemy?.hp || 0).toLocaleString()}/ {(currentEnemy?.maxHp || 0).toLocaleString()}
                                </span>
                            </div>
                            <div className="bg-gray-700/70 rounded-full h-3 overflow-hidden">
                                <div
                                    className={`h-full transition-all duration-500 ${currentEnemy && (currentEnemy.hp / currentEnemy.maxHp) > 0.5 ? "bg-gradient-to-r from-green-500 to-green-400" : currentEnemy && (currentEnemy.hp / currentEnemy.maxHp) > 0.2 ? "bg-gradient-to-r from-yellow-500 to-yellow-400" : "bg-gradient-to-r from-red-500 to-red-400 hp-warning-blink"}`}
                                    style={{
                                        width: `${currentEnemy ? currentEnemy.hp / currentEnemy.maxHp * 100 : 0}%`
                                    }}></div>
                            </div>
                        </div>
                    {}
                    <div className="flex items-center mt-2">
                        <i className="fas fa-claw text-red-400 mr-2"></i>
                        <span className="text-gray-300">攻击力: <span className="text-white font-medium">{(currentEnemy?.atk || 0).toLocaleString()}</span></span>
                    </div>
                </div>
            </div>
        </div>
        {}
        <div className="mb-6">
            <button
                className="btn-reset text-white font-bold py-2 px-6 rounded-full flex items-center mb-4"
                onClick={() => setShowTeamPanel(!showTeamPanel)}>
                <i
                    className={`fas ${showTeamPanel ? "fa-chevron-up" : "fa-chevron-down"} mr-2`}></i>
                {showTeamPanel ? "收起队伍" : "查看队伍"}
            </button>
            {showTeamPanel && <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {}
                <div className="glassmorphism p-4 rounded-xl">
                    <h4 className="text-lg font-semibold mb-3 text-blue-400 flex items-center">
                        <i className="fas fa-users mr-2"></i>我方队伍
                                      </h4>
                    <div className="flex flex-wrap gap-2">
                        {playerTeam.map(character => <div
                            key={character.id}
                            className={`glassmorphism py-2 px-3 rounded-full text-sm transition-all duration-300 ${character.id === currentPlayer?.id ? "border-2 border-blue-500 bg-blue-900/30 animate-pulse-glow" : !character.isAlive ? "opacity-60 grayscale" : "hover:scale-105 hover:bg-blue-900/20"}`}
                            onClick={() => switchCharacter(character)}>
                            <div className="flex items-center">
                                <span className={`mr-2 ${!character.isAlive ? "line-through" : ""}`}>
                                    {character.name}
                                </span>
                                <span className="text-xs text-gray-400">
                                    {character.hp}/{character.maxHp}
                                </span>
                            </div>
                        </div>)}
                    </div>
                </div>
                {}
                <div className="glassmorphism p-4 rounded-xl">
                    <h4 className="text-lg font-semibold mb-3 text-red-400 flex items-center">
                        <i className="fas fa-skull-crossbones mr-2"></i>敌方队伍
                                      </h4>
                    <div className="flex flex-wrap gap-2">
                        {enemyTeam.map(character => <div
                            key={character.id}
                            className={`glassmorphism py-2 px-3 rounded-full text-sm transition-all duration-300 ${character.id === currentEnemy?.id ? "border-2 border-red-500 bg-red-900/30 animate-pulse-glow" : !character.isAlive ? "opacity-60 grayscale" : "hover:scale-105 hover:bg-red-900/20"}`}>
                            <div className="flex items-center">
                                <span className={`mr-2 ${!character.isAlive ? "line-through" : ""}`}>
                                    {character.name}
                                </span>
                                <span className="text-xs text-gray-400">
                                    {character.hp}/{character.maxHp}
                                </span>
                            </div>
                        </div>)}
                    </div>
                </div>
            </div>}
        </div>
        {}
        <div className="flex justify-center items-center gap-3 mb-6">
            <button
                className="btn-attack text-white font-bold py-3 px-10 rounded-full flex items-center text-lg"
                onClick={attack}
                disabled={gameStatus !== "playing" || turnState.current !== "player"}>
                <i className="fas fa-bolt mr-2"></i>攻击
                        </button>
            <button
                className="btn-attack text-white font-bold py-3 px-10 rounded-full flex items-center text-lg"
                onClick={() => setAutoAttack(prev => !prev)}
                disabled={gameStatus !== "playing"}>
                <i className="fas fa-sync-alt mr-2"></i>{autoAttack ? "停止自动" : "自动攻击"}
                        </button>
            <span className={`${autoAttack ? "bg-green-500 animate-pulse" : "bg-gray-500"} w-2.5 h-2.5 rounded-full`}></span>
            <input
                type="number"
                min={200}
                max={5000}
                value={attackIntervalMs}
                onChange={e => setAttackIntervalMs(Number(e.target.value) || 500)}
                className="ml-1 bg-black/30 border border-gray-600 text-white text-sm rounded-full px-3 py-1 w-24 focus:outline-none"
            />
        </div>
        {}
        <div className="glassmorphism p-4 rounded-xl mb-6">
            <h4 className="text-lg font-semibold mb-3 text-yellow-400 flex items-center">
                <i className="fas fa-history mr-2"></i>战斗日志
                        </h4>
            <div className="combat-log p-3 bg-black/20 rounded-lg max-h-48">
                {battleLog.map((log, index) => <div
                    key={index}
                    className="log-entry my-1.5 p-2 rounded bg-black/30 border-l-4 border-yellow-500 animate-fade-in">
                    <span className="text-yellow-400 font-medium">第{log.round}回合: </span>
                    <span
                        className={log.content.includes("你") || log.content.includes("玩家") ? "text-blue-300" : "text-red-300"}>
                        {log.content}
                    </span>
                </div>)}
            </div>
        </div>
        {}
        <div className="flex justify-center gap-4">
            <button
                className="btn-reset text-white font-bold py-2.5 px-6 rounded-full flex items-center">
                <i className="fas fa-redo-alt mr-2"></i>重新开始
                         </button>
            <button
                className="return-button bg-gray-700 hover:bg-gray-600 text-white font-bold py-2.5 px-6 rounded-full flex items-center transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
                onClick={returnToHome}
                aria-label="返回游戏主页"
                aria-busy={isNavigating}
                title="返回游戏主页">
                <i className="fas fa-home mr-2"></i>返回游戏主页
                        </button>
        </div>
    </div>;

    

    const renderBattleEnd = () => {
        if (!showBattleEnd)
            return null;

        const {
            totalDamageDealt,
            totalDamageTaken,
            turnsUsed,
            battleDuration
        } = combatStats;

        const survivedCount = playerTeam.filter(p => p.isAlive).length;
        const defeatedCount = playerTeam.filter(p => !p.isAlive).length;

        return (
            <div
                className="battle-end-overlay fixed inset-0 z-50 flex items-center justify-center bg-black/80">
                <div
                    className="battle-end-container glassmorphism p-8 rounded-xl max-w-md w-full mx-4">
                    <h2
                        className={`text-3xl font-bold mb-6 text-center ${battleResult === "victory" ? "text-green-400 animate-victory" : "text-red-400"}`}>
                        {battleResult === "victory" ? "胜利！" : "失败！"}
                    </h2>
                    <div className="battle-stats space-y-3 mb-8">
                        <div className="stat-item flex justify-between p-3 bg-black/30 rounded-lg">
                            <span className="stat-label text-gray-300">战斗时长：</span>
                            <span className="stat-value font-bold text-white">{battleDuration}秒</span>
                        </div>
                        <div className="stat-item flex justify-between p-3 bg-black/30 rounded-lg">
                            <span className="stat-label text-gray-300">回合数：</span>
                            <span className="stat-value font-bold text-white">{turnsUsed}回合</span>
                        </div>
                        <div className="stat-item flex justify-between p-3 bg-black/30 rounded-lg">
                            <span className="stat-label text-gray-300">总伤害：</span>
                            <span className="stat-value font-bold text-yellow-400">{totalDamageDealt}点</span>
                        </div>
                        <div className="stat-item flex justify-between p-3 bg-black/30 rounded-lg">
                            <span className="stat-label text-gray-300">受到伤害：</span>
                            <span className="stat-value font-bold text-red-400">{totalDamageTaken}点</span>
                        </div>
                        <div className="stat-item flex justify-between p-3 bg-black/30 rounded-lg">
                            <span className="stat-label text-gray-300">存活角色：</span>
                            <span className="stat-value font-bold text-green-400">{survivedCount}个</span>
                        </div>
                        <div className="stat-item flex justify-between p-3 bg-black/30 rounded-lg">
                            <span className="stat-label text-gray-300">被击败角色：</span>
                            <span className="stat-value font-bold text-gray-400">{defeatedCount}个</span>
                        </div>
                    </div>
                    <div className="battle-end-buttons flex gap-4 justify-center">
                        <button
                            className="restart-button bg-yellow-600 hover:bg-yellow-500 text-white font-bold py-3 px-8 rounded-full flex items-center transition-all duration-300"
                            onClick={restartBattle}>
                            <i className="fas fa-redo-alt mr-2"></i>重新开始
                                        </button>
                        <button
                            className="return-button bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-8 rounded-full flex items-center transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
                            onClick={returnToHome}
                            aria-label="返回游戏主页"
                            aria-busy={isNavigating}
                            title="返回游戏主页">
                            <i className="fas fa-home mr-2"></i>返回游戏主页
                                        </button>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div
            className={`special-level-battle min-h-screen bg-gradient-to-b from-gray-900 to-indigo-950 text-white pt-6 pb-16 ${isNavigating ? "page-fade-out" : ""}`}>
            {}
            <header className="battle-header w-full max-w-5xl mx-auto px-4 mb-6">
                <div
                    className="flex justify-between items-center glassmorphism p-4 rounded-xl">
                    <button
                        className="back-btn bg-indigo-900/70 hover:bg-indigo-800 text-white p-2.5 rounded-full transition-all duration-300"
                        onClick={returnToHome}>
                        <i className="fas fa-arrow-left"></i>
                    </button>
                    <h1
                        className="text-2xl md:text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-orange-400">特殊关卡战斗
                                  </h1>
                    <div className="turn-status">
                        {gameStatus === "playing" && <div className="flex items-center gap-2">
                            <button
                                className="btn-skip bg-purple-700 hover:bg-purple-600 text-white font-bold px-4 py-1.5 rounded-full transition-all duration-300"
                                onClick={skipBattle}>
                                跳过战斗
                            </button>
                            {turnState.current === "player" && <span
                                className="player-turn glassmorphism bg-gradient-to-r from-green-600 to-green-500 text-white font-medium px-4 py-1.5 rounded-full animate-pulse">我方回合</span>}
                        </div>}
                    </div>
                </div>
            </header>
            {showTeamSelection ? renderTeamSelection() : renderBattleField()}
            {showBattleEnd && renderBattleEnd()}
            {isSkipping && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
                <div className="flex flex-col items-center gap-3">
                    <div className="w-12 h-12 border-4 border-gray-300 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-white text-sm">正在跳过战斗...</span>
                </div>
            </div>}
            {isNavigating && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
                <div className="w-12 h-12 border-4 border-gray-300 border-t-transparent rounded-full animate-spin"></div>
            </div>}
        </div>
    );
};

export default SpecialLevelBattle;
