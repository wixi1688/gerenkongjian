import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../hooks/useTheme';

// 定义重大事件类型
interface MajorEvent {
  id: string;
  title: string;
  time: string;
  description: string;
  importance: 'high' | 'medium' | 'low';
  icon: string;
}

const StoryMajorEventsPage: React.FC = () => {
  const { theme } = useTheme();
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  
  // 重大事件数据
  const majorEvents: MajorEvent[] = [
    {
      id: 'event-1',
      title: '光明大陆的诞生',
      time: '创世之初',
      description: '在宇宙诞生的混沌之中，两股强大的力量相互交织——光明与暗影。它们既相互对立，又相互依存，共同维持着宇宙的平衡。在这两股力量的交汇处，诞生了一片美丽的世界——光明大陆。',
      importance: 'high',
      icon: 'fa-globe'
    },
    {
      id: 'event-2',
      title: '守护者的出现',
      time: '远古时代',
      description: '光明大陆诞生的同时，从世界本源之力中自然孕育出了两位守护者——清鸢与宿槐。她们本为同源一体，如同双生姐妹，清鸢代表着光明与生命，宿槐代表着自然与平衡。',
      importance: 'high',
      icon: 'fa-user-shield'
    },
    {
      id: 'event-3',
      title: '人类文明的崛起',
      time: '古代时期',
      description: '随着时间的推移，人类文明逐渐发展壮大。他们开始在光明大陆上建立自己的家园，发展出独特的文化和魔法体系。人类与自然和谐相处，受到守护者的祝福。',
      importance: 'medium',
      icon: 'fa-city'
    },
    {
      id: 'event-4',
      title: '环境失衡与宿槐的质疑',
      time: '近代早期',
      description: '人类开始过度开发自然，砍伐森林，污染河流，破坏了大陆的生态平衡。宿槐对此感到无比痛心，多次向人类发出警告，但都被置若罔闻。她开始质疑自己守护人类的意义。',
      importance: 'high',
      icon: 'fa-exclamation-triangle'
    },
    {
      id: 'event-5',
      title: '宿槐的堕落',
      time: '近代中期',
      description: '在无尽的痛苦与愤怒中，宿槐的内心逐渐被黑暗所吞噬。她改名为宿槐，决心用自己的方式守护这个世界——即使那意味着要与姐姐为敌。宿槐成为了暗影女王，率领着暗影大军开始了对光明大陆的入侵。',
      importance: 'high',
      icon: 'fa-ghost'
    },
    {
      id: 'event-6',
      title: '徐清岚的到来',
      time: '现代初期',
      description: '来自异世界的魔法少女徐清岚，在古老的魔法阵中启动了传送咒语，穿越到了光明大陆。她的到来为这场光暗之战带来了新的变数。',
      importance: 'high',
      icon: 'fa-wand-magic-sparkles'
    },
    {
      id: 'event-7',
      title: '善•猫教主的救赎',
      time: '现代中期',
      description: '清鸢用光明之力净化了被黑暗侵蚀的小猫，赋予它全新的生命形态。重生后的小猫获得了更加强大的光明之力，它决定用这份力量来弥补自己过去的过错，成为了善•猫教主。',
      importance: 'medium',
      icon: 'fa-cat'
    },
    {
      id: 'event-8',
      title: '星界之门的危机',
      time: '现代后期',
      description: '在季灾的精心策划下，徐清岚（暗）带着暗影大军突然出现在星界山顶，发动了对青玄的突袭。尽管青玄展现出了惊人的实力，但最终还是因为寡不敌众而坠落，星界之门的平衡被打破。',
      importance: 'high',
      icon: 'fa-gate-open'
    },
    {
      id: 'event-9',
      title: '徐清岚的觉醒',
      time: '当代',
      description: '在与宿槐的最终决战中，徐清岚为了保护清鸢和善•猫教主，激发了体内沉睡的星界之力，完成了前所未有的神化觉醒。神化后的徐清岚获得了无与伦比的力量，成为了对抗暗影的关键。',
      importance: 'high',
      icon: 'fa-star'
    },
    {
      id: 'event-10',
      title: '明渊的秘密',
      time: '当代',
      description: '在光明大陆的最边缘，有一个被称为"明渊"的神秘地方。这里是光明与暗影的交汇之处，也是通往星界之门的最后关键。一个名为慕容言风的神秘人类居住在这里，他的存在为光暗之战增添了更多变数。',
      importance: 'medium',
      icon: 'fa-mountain'
    }
  ];
  
  // 过滤事件
  const filteredEvents = activeFilter === 'all' 
    ? majorEvents 
    : majorEvents.filter(event => event.importance === activeFilter);
  
  // 获取事件重要性样式
  const getImportanceClass = (importance: string) => {
    switch (importance) {
      case 'high':
        return 'bg-red-900/50 text-red-400';
      case 'medium':
        return 'bg-yellow-900/50 text-yellow-400';
      case 'low':
        return 'bg-green-900/50 text-green-400';
      default:
        return 'bg-gray-700/50 text-gray-400';
    }
  };
  
  // 获取时间线图标样式
  const getTimelineIconClass = (importance: string) => {
    switch (importance) {
      case 'high':
        return 'bg-red-500 text-white border-red-400';
      case 'medium':
        return 'bg-yellow-500 text-white border-yellow-400';
      case 'low':
        return 'bg-green-500 text-white border-green-400';
      default:
        return 'bg-gray-500 text-white border-gray-400';
    }
  };

  return (
    <div className={`min-h-screen ${theme === 'light' ? 'bg-gradient-to-b from-gray-50 to-gray-100' : 'bg-gradient-to-b from-gray-950 via-gray-900 to-indigo-950'} text-gray-900 dark:text-white transition-colors duration-700 p-4 relative overflow-hidden`}>
      {/* 背景动态光效 - 增强版 */}
      <div className="fixed top-0 left-0 right-0 bottom-0 pointer-events-none z-0">
        {/* 主光晕 - 中央 */}
        <motion.div 
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vw] rounded-full blur-[100px] ${
            theme === 'light' ? 'bg-blue-100/30' : 'bg-indigo-900/20'
          }`}
          animate={{ 
            scale: [1, 1.05, 1],
            opacity: [0.3, 0.4, 0.3]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        />
        
        {/* 辅助光晕 - 右上 */}
        <motion.div 
          className={`absolute top-[15%] right-[10%] w-[30vw] h-[30vw] rounded-full blur-[80px] ${
            theme === 'light' ? 'bg-blue-200/20' : 'bg-blue-900/20'
          }`}
          animate={{ 
            scale: [1, 1.2, 1],
            x: [0, -30, 0],
            y: [0, -20, 0],
            opacity: [0.2, 0.3, 0.2]
          }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        />
        
        {/* 辅助光晕 - 左下 */}
        <motion.div 
          className={`absolute bottom-[20%] left-[15%] w-[25vw] h-[25vw] rounded-full blur-[70px] ${
            theme === 'light' ? 'bg-purple-200/20' : 'bg-purple-900/20'
          }`}
          animate={{ 
            scale: [1, 1.3, 1],
            x: [0, 20, 0],
            y: [0, 30, 0],
            opacity: [0.2, 0.35, 0.2]
          }}
          transition={{ duration: 22, repeat: Infinity, ease: "easeInOut", delay: 3 }}
        />
        
        {/* 点缀光晕 - 左上 */}
        <motion.div 
          className={`absolute top-[30%] left-[20%] w-[15vw] h-[15vw] rounded-full blur-[50px] ${
            theme === 'light' ? 'bg-cyan-200/20' : 'bg-cyan-900/20'
          }`}
          animate={{ 
            scale: [1, 1.5, 1],
            opacity: [0.1, 0.25, 0.1]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        />
        
        {/* 点缀光晕 - 右下 */}
        <motion.div 
          className={`absolute bottom-[35%] right-[25%] w-[18vw] h-[18vw] rounded-full blur-[60px] ${
            theme === 'light' ? 'bg-indigo-200/20' : 'bg-indigo-900/20'
          }`}
          animate={{ 
            scale: [1, 1.4, 1],
            opacity: [0.15, 0.3, 0.15]
          }}
          transition={{ duration: 17, repeat: Infinity, ease: "easeInOut", delay: 4 }}
        />
      </div>
      
       {/* 页面头部 */}
      <header className="max-w-6xl mx-auto mb-8 relative z-10">
        <div className="absolute top-0 left-0 z-20">
          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className={`p-3 rounded-full border text-white hover:shadow-xl transition-all duration-300 flex items-center justify-center backdrop-blur-md
              ${theme === 'light' 
                ? 'bg-white/80 border-white/20 text-gray-800 hover:bg-white shadow-gray-200/50' 
                : 'bg-gray-900/80 border-gray-700/50 hover:bg-gray-800/90 shadow-gray-800/50'
              }`}
            onClick={() => navigate(-1)}
            aria-label="返回上一页"
          >
            <i className="fa-solid fa-arrow-left text-xl"></i>
          </motion.button>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="flex flex-col items-center justify-center text-center pt-12 pb-4"
        >
          {/* 标题装饰 */}
          <motion.div 
            className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-1 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: '8rem' }}
            transition={{ duration: 0.8, delay: 0.3 }}
          />
          
          <motion.h1 
            className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent"
            animate={{ 
              textShadow: [
                '0 0 10px rgba(59, 130, 246, 0.2)',
                '0 0 20px rgba(59, 130, 246, 0.3)',
                '0 0 10px rgba(59, 130, 246, 0.2)'
              ]
            }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
            重大事件
          </motion.h1>
          
          <motion.p 
            className={`max-w-2xl ${theme === 'light' ? 'text-gray-600' : 'text-gray-300'}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.5 }}
          >
            探索游戏中发生的重大事件时间线，了解光明与暗影之战的关键转折点和重要历史事件。
          </motion.p>
        </motion.div>
      </header>
      
       {/* 主要内容 */}
      <main className="max-w-6xl mx-auto pb-16 relative z-10">
        {/* 筛选器 */}
        <motion.div 
          className="flex flex-wrap gap-2 mb-10 justify-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
        >
          <motion.button
            className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 backdrop-blur-sm shadow-lg
              ${activeFilter === 'all' 
                ? theme === 'light' 
                  ? 'bg-white/90 text-gray-800 shadow-white/40' 
                  : 'bg-gray-900/90 text-white shadow-gray-800/40'
                : theme === 'light' 
                  ? 'bg-white/60 text-gray-600 hover:bg-white/90 hover:shadow-white/40' 
                  : 'bg-gray-900/60 text-gray-400 hover:bg-gray-900/90 hover:shadow-gray-800/40'
              }`}
            onClick={() => setActiveFilter('all')}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            所有事件
          </motion.button>
          
          <motion.button
            className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 backdrop-blur-sm shadow-lg
              ${activeFilter === 'high' 
                ? theme === 'light' 
                  ? 'bg-red-100/90 text-red-800 shadow-red-200/40' 
                  : 'bg-red-900/30 text-red-400 shadow-red-900/30'
                : theme === 'light' 
                  ? 'bg-red-50/70 text-red-700 hover:bg-red-100/90 hover:shadow-red-200/40' 
                  : 'bg-red-900/10 text-red-400/70 hover:bg-red-900/30 hover:shadow-red-900/30'
              }`}
            onClick={() => setActiveFilter('high')}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <i className="fa-solid fa-exclamation-circle mr-1.5"></i>重要事件
          </motion.button>
          
          <motion.button
            className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 backdrop-blur-sm shadow-lg
              ${activeFilter === 'medium' 
                ? theme === 'light' 
                  ? 'bg-yellow-100/90 text-yellow-800 shadow-yellow-200/40' 
                  : 'bg-yellow-900/30 text-yellow-400 shadow-yellow-900/30'
                : theme === 'light' 
                  ? 'bg-yellow-50/70 text-yellow-700 hover:bg-yellow-100/90 hover:shadow-yellow-200/40' 
                  : 'bg-yellow-900/10 text-yellow-400/70 hover:bg-yellow-900/30 hover:shadow-yellow-900/30'
              }`}
            onClick={() => setActiveFilter('medium')}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <i className="fa-solid fa-circle-info mr-1.5"></i>一般事件
          </motion.button>
        </motion.div>
        
        {/* 时间线 */}
        <div className="relative">
          {/* 中央线 - 增强版 */}
          <motion.div 
            className={`absolute left-0 md:left-1/2 top-0 bottom-0 w-0.5 transform md:-translate-x-1/2
              ${theme === 'light' ? 'bg-blue-200' : 'bg-gray-700'}`}
            initial={{ height: 0 }}
            animate={{ height: '100%' }}
            transition={{ duration: 1.5, ease: "easeOut" }}
          />
          
          {/* 时间线装饰效果 */}
          <div className="absolute left-0 md:left-1/2 top-0 transform md:-translate-x-1/2">
            {filteredEvents.map((_, index) => (
              <motion.div
                key={index}
                className={`absolute w-12 h-12 -translate-x-1/2 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 rounded-full blur-md`}
                style={{ top: `${index * 100 + 20}px` }}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 0.7, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
              />
            ))}
          </div>
          
          {/* 事件列表 */}
          <div className="space-y-12">
            {filteredEvents.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.3 + index * 0.1 }}
                className={`relative flex flex-col md:flex-row ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
              >
                {/* 时间线图标 */}
                <div className="absolute left-0 md:left-1/2 top-0 transform -translate-y-1/2 md:-translate-x-1/2 z-10">
                  <motion.div 
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${getTimelineIconClass(event.importance)} shadow-lg`}
                    style={{ 
                      boxShadow: theme === 'light' 
                        ? `0 0 0 4px white, 0 0 15px ${
                            event.importance === 'high' ? 'rgba(239, 68, 68, 0.3)' :
                            event.importance === 'medium' ? 'rgba(234, 179, 8, 0.3)' :
                            'rgba(34, 197, 94, 0.3)'
                          }` 
                        : `0 0 0 4px #1f2937, 0 0 15px ${
                            event.importance === 'high' ? 'rgba(239, 68, 68, 0.3)' :
                            event.importance === 'medium' ? 'rgba(234, 179, 8, 0.3)' :
                            'rgba(34, 197, 94, 0.3)'
                          }`
                    }}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ 
                      type: "spring", 
                      stiffness: 260, 
                      damping: 20,
                      delay: 0.4 + index * 0.1
                    }}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    <i className={`fa-solid ${event.icon} text-sm`}></i>
                  </motion.div>
                </div>
                
                {/* 左侧内容 (偶数行) / 右侧内容 (奇数行) */}
                <motion.div 
                  className={`flex-1 md:pr-12 ${index % 2 === 0 ? 'md:text-right md:pr-12 md:pl-0' : 'md:pl-12 md:pr-0'} mt-6 md:mt-0`}
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className={`inline-block mb-2 text-xs font-medium px-2 py-0.5 rounded-full ${getImportanceClass(event.importance)}`}>
                    {event.time}
                  </div>
                  <h2 className={`text-xl font-bold mb-2 ${theme === 'light' ? 'text-gray-800' : 'text-white'}`}>{event.title}</h2>
                  <p className={theme === 'light' ? 'text-gray-600' : 'text-gray-300'}>{event.description}</p>
                </motion.div>
                
                {/* 右侧空间 (偶数行) / 左侧空间 (奇数行) */}
                <div className="flex-1"></div>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* 历史地图 */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className={`mt-16 rounded-xl p-6 border relative overflow-hidden backdrop-blur-md shadow-xl
            ${theme === 'light' 
              ? 'bg-white/80 border-white/40 shadow-white/20' 
              : 'bg-gray-900/50 border-gray-700/50 shadow-gray-900/50'
            }`}
        >
          {/* 装饰元素 */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl"></div>
          
          <h2 className={`text-xl font-bold mb-4 flex items-center relative z-10
            ${theme === 'light' ? 'text-gray-800' : 'text-white'}`}>
            <i className="fa-solid fa-map-location-dot text-blue-400 mr-2"></i>
            光明大陆历史地图
          </h2>
          
          <div className={`aspect-video rounded-lg overflow-hidden relative mb-4
            ${theme === 'light' ? 'bg-gray-100' : 'bg-gray-950'}`}>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className={`text-center p-8
                ${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>
                <motion.div 
                  animate={{ 
                    rotate: [0, 10, 0, -10, 0],
                    scale: [1, 1.05, 1]
                  }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                >
                  <i className="fa-solid fa-map-location-dot text-4xl mb-4"></i>
                </motion.div>
                <p>光明大陆地图正在加载中...</p>
                <p className="text-sm mt-2">显示重大事件发生的地理位置</p>
              </div>
            </div>
          </div>
          
          <p className={`text-sm
            ${theme === 'light' ? 'text-gray-600' : 'text-gray-400'}`}>
            此地图展示了光明大陆的主要区域和重大事件发生的地理位置。随着您探索更多剧情，地图将逐渐解锁更多区域和细节。
          </p>
        </motion.div>
        
        {/* 历史人物关系图 */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className={`mt-8 rounded-xl p-6 border relative overflow-hidden backdrop-blur-md shadow-xl
            ${theme === 'light' 
              ? 'bg-white/80 border-white/40 shadow-white/20' 
              : 'bg-gray-900/50 border-gray-700/50 shadow-gray-900/50'
            }`}
        >
          {/* 装饰元素 */}
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-purple-500/10 rounded-full blur-3xl"></div>
          
          <h2 className={`text-xl font-bold mb-4 flex items-center relative z-10
            ${theme === 'light' ? 'text-gray-800' : 'text-white'}`}>
            <i className="fa-solid fa-network-wired text-purple-400 mr-2"></i>
            主要人物关系
          </h2>
          
          <div className={`aspect-square md:aspect-video rounded-lg overflow-hidden relative
            ${theme === 'light' ? 'bg-gray-100' : 'bg-gray-950'}`}>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className={`text-center p-8
                ${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>
                <motion.div 
                  animate={{ 
                    y: [0, -5, 0],
                    scale: [1, 1.05, 1]
                  }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                >
                  <i className="fa-solid fa-users text-4xl mb-4"></i>
                </motion.div>
                <p>人物关系图正在加载中...</p>
                <p className="text-sm mt-2">展示主要角色之间的关联</p>
              </div>
            </div>
          </div>
        </motion.div>
      </main>
      
      {/* 页脚 */}
      <footer className={`py-6 text-center relative z-10 border-t
        ${theme === 'light' 
          ? 'bg-white/80 border-gray-200 text-gray-600' 
          : 'bg-gray-900/80 border-gray-800 text-gray-400'
        } backdrop-blur-sm`}>
        <p>© 2025 光明与暗影之战 - 历史大事件</p>
      </footer>
    </div>
  );
};

export default StoryMajorEventsPage;