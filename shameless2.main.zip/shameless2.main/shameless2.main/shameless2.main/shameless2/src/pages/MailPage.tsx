import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

// 定义邮件类型
interface Mail {
  id: string;
  title: string;
  sender: string;
  senderAvatar: string;
  time: string;
  date: string;
  content: string;
  isRead: boolean;
  attachments?: MailAttachment[];
  summary: string;
}

// 定义邮件附件类型
interface MailAttachment {
  id: string;
  type: 'sun' | 'plant' | 'achievement';
  name: string;
  icon: string;
  quantity: number;
  isCollected: boolean;
  description?: string;
}

// 邮件列表面组件
interface MailListProps {
  mails: Mail[];
  selectedMailId: string;
  onSelectMail: (mail: Mail) => void;
  onToggleReadStatus: (mailId: string) => void;
  onDeleteMail: (mailId: string) => void;
  formatDate: (date: string) => string;
}

const MailList: React.FC<MailListProps> = ({
  mails,
  selectedMailId,
  onSelectMail,
  onToggleReadStatus,
  onDeleteMail,
  formatDate
}) => {
  return (
    <div>
      {mails.length === 0 ? (
        <div className="p-6 text-center text-gray-400">
          <i className="fa-solid fa-inbox text-4xl mb-2"></i>
          <p>暂无邮件</p>
        </div>
      ) : (
        mails.map(mail => (
          <motion.div
            key={mail.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className={`
              p-4 border-b border-gray-700 cursor-pointer
              ${selectedMailId === mail.id ? 'bg-gray-700' : 'hover:bg-gray-700/50'}
              ${!mail.isRead ? 'font-medium' : 'text-gray-400'}
              transition-all duration-300
            `}
            onClick={() => onSelectMail(mail)}
          >
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center">
                {!mail.isRead && (
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                )}
                <h3 className="truncate max-w-[calc(100%-24px)]">{mail.title}</h3>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleReadStatus(mail.id);
                  }}
                  className="text-gray-500 hover:text-white p-1"
                  title={mail.isRead ? '标记为未读' : '标记为已读'}
                >
                  <i className="fa-solid fa-envelope"></i>
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (window.confirm('确定要删除这封邮件吗？')) {
                      onDeleteMail(mail.id);
                    }
                  }}
                  className="text-gray-500 hover:text-red-400 p-1"
                  title="删除邮件"
                >
                  <i className="fa-solid fa-trash"></i>
                </button>
              </div>
            </div>
            <p className="text-xs truncate">{mail.sender}</p>
            <div className="flex justify-between items-center mt-2">
              <p className="text-xs truncate max-w-[80%]">{mail.summary}</p>
              <span className="text-xs">{formatDate(mail.date)}</span>
            </div>
            
            {/* 附件指示器 */}
            {mail.attachments && mail.attachments.length > 0 && (
              <div className="mt-2 flex items-center">
                <i className="fa-solid fa-paperclip text-gray-500 mr-1 text-xs"></i>
                <span className="text-xs text-gray-500">
                  {mail.attachments.some(a => !a.isCollected) ? '有未领取附件' : '附件已领取'}
                </span>
              </div>
            )}
          </motion.div>
        ))
      )}
    </div>
  );
};

// 邮件内容面组件
interface MailContentProps {
  mail: Mail;
  showFullContent: boolean;
  onToggleFullContent: (show: boolean) => void;
  onToggleReadStatus: (mailId: string) => void;
  onDeleteMail: (mailId: string) => void;
  onCollectAttachment: (mailId: string, attachmentId: string) => void;
  onCollectAllAttachments: () => void;
}

const MailContent: React.FC<MailContentProps> = ({
  mail,
  showFullContent,
  onToggleFullContent,
  onToggleReadStatus,
  onDeleteMail,
  onCollectAttachment,
  onCollectAllAttachments
}) => {
  // 检查是否有未领取的附件
  const hasUncollectedAttachments = mail.attachments && mail.attachments.some(a => !a.isCollected);

  return (
    <div className="bg-gray-800 rounded-xl h-full flex flex-col">
      {/* 邮件头部 */}
      <div className="p-6 border-b border-gray-700">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold mb-2">{mail.title}</h2>
            <div className="flex items-center">
              <img 
                src={mail.senderAvatar} 
                alt={mail.sender}
                className="w-8 h-8 rounded-full mr-3 object-cover"
              />
              <div>
                <p className="font-medium">{mail.sender}</p>
                <p className="text-sm text-gray-400">{mail.date} {mail.time}</p>
              </div>
            </div>
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={() => onToggleReadStatus(mail.id)}
              className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-1 rounded-lg text-sm transition-colors"
            >
              {mail.isRead ? '标记为未读' : '标记为已读'}
            </button>
            <button
              onClick={() => {
                if (window.confirm('确定要删除这封邮件吗？')) {
                  onDeleteMail(mail.id);
                }
              }}
              className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-lg text-sm transition-colors"
            >
              删除
            </button>
          </div>
        </div>
      </div>
      
      {/* 邮件正文 */}
      <div className="flex-1 p-6 overflow-y-auto">
        <div className={`prose prose-invert max-w-none ${showFullContent ? '' : 'line-clamp-10'}`}>
          <p>{mail.content}</p>
        </div>
        
        {mail.content.length > 200 && !showFullContent && (
          <button
            onClick={() => onToggleFullContent(true)}
            className="mt-4 text-blue-400 hover:text-blue-300 transition-colors text-sm"
          >
            显示全部内容 <i className="fa-solid fa-chevron-down ml-1"></i>
          </button>
        )}
        
        {showFullContent && (
          <button
            onClick={() => onToggleFullContent(false)}
            className="mt-4 text-blue-400 hover:text-blue-300 transition-colors text-sm"
          >
            收起内容 <i className="fa-solid fa-chevron-up ml-1"></i>
          </button>
        )}
      </div>
      
      {/* 附件区域 */}
      {mail.attachments && mail.attachments.length > 0 && (
        <div className="p-6 border-t border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold flex items-center">
              <i className="fa-solid fa-paperclip mr-2"></i> 附件
            </h3>
            
            {hasUncollectedAttachments && (
              <button
                onClick={onCollectAllAttachments}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm transition-colors flex items-center"
              >
                <i className="fa-solid fa-gift mr-1"></i> 一键领取
              </button>
            )}
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {mail.attachments.map(attachment => (
              <motion.div
                key={attachment.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.2 }}
                className={`
                  p-4 rounded-lg border flex items-center justify-between
                  ${attachment.isCollected 
                    ? 'bg-gray-700/50 border-gray-600 opacity-70' 
                    : 'bg-gradient-to-r from-gray-800 to-gray-700 border-gray-600'
                  }
                `}
              >
                <div className="flex items-center">
                  <div className={`
                    w-10 h-10 rounded-full flex items-center justify-center mr-3
                    bg-gradient-to-br ${attachmentTypeColors[attachment.type]}
                  `}>
                    <i className={`fa-solid ${attachmentTypeIcons[attachment.type]} text-white`}></i>
                  </div>
                  
                  <div>
                    <p className="font-medium">{attachment.name}</p>
                    <p className="text-sm text-gray-400">{attachment.quantity}个</p>
                    {attachment.description && (
                      <p className="text-xs text-gray-500 mt-1">{attachment.description}</p>
                    )}
                  </div>
                </div>
                
                {!attachment.isCollected ? (
                  <button
                    onClick={() => onCollectAttachment(mail.id, attachment.id)}
                    className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded-lg text-sm transition-colors"
                  >
                    领取
                  </button>
                ) : (
                  <div className="text-green-400 text-sm flex items-center">
                    <i className="fa-solid fa-check-circle mr-1"></i> 已领取
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// 邮件附件类型图标映射
const attachmentTypeIcons: Record<MailAttachment['type'], string> = {
  sun: 'fa-sun',
  plant: 'fa-seedling',
  achievement: 'fa-trophy'
};

// 邮件附件类型颜色映射
const attachmentTypeColors: Record<MailAttachment['type'], string> = {
  sun: 'from-yellow-600 to-yellow-500',
  plant: 'from-green-600 to-green-500',
  achievement: 'from-orange-600 to-orange-500'
};

const MailPage: React.FC = () => {
  const navigate = useNavigate();
  const [mails, setMails] = useState<Mail[]>([]);
  const [selectedMail, setSelectedMail] = useState<Mail | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showFullContent, setShowFullContent] = useState(false);
  const [isMobileView, setIsMobileView] = useState(false);
  const [mobileTab, setMobileTab] = useState<'list' | 'content'>('list');
  const [isLoading, setIsLoading] = useState(true);

  // 检查是否为移动视图
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 768);
    };
    
    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);
    
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  // 初始化邮件数据
  useEffect(() => {
    // 模拟加载延迟
    const timer = setTimeout(() => {
      // 确保使用包含最新邮件的默认数据
      // 开发环境下不使用localStorage缓存，确保可以看到最新添加的邮件
      const initialMails: Mail[] = getDefaultMails();
      
      setMails(initialMails);
      setUnreadCount(initialMails.filter(mail => !mail.isRead).length);
      setIsLoading(false);
    }, 800);
    
    return () => clearTimeout(timer);
  }, []);

  // 保存邮件数据到localStorage
  useEffect(() => {
    if (!isLoading && (import.meta.env.MODE !== 'development')) {
      localStorage.setItem('pvzMails', JSON.stringify(mails));
    }
  }, [mails, isLoading]);

  // 默认邮件数据
  const getDefaultMails = (): Mail[] => [
    {
      id: '1',
      title: '给进入游戏的玩家的一封信',
      sender: 'wixi',
      senderAvatar: 'https://lf-code-agent.coze.cn/obj/x-ai-cn/307170232066/attachment/wixi_20251030201020.jpg',
      time: '20:11',
      date: '2025-10-30',
      content: '亲爱的玩家，你好。我是wixi，一个大好人，妈咪妈咪哄。要天天开心，不要让自己伤心，生活虽然不是一帆风顺的，但我们依然要前行',
      isRead: false,
      summary: '亲爱的玩家，你好。我是wixi，一个大好人...',
      attachments: []
    },
    {
      id: '2',
      title: 'wixi给玩家的第二封邮件',
      sender: 'wixi',
      senderAvatar: 'https://lf-code-agent.coze.cn/obj/x-ai-cn/307170232066/attachment/wixi_20251030201020.jpg',
      time: '20:54',
      date: '2025-10-30',
      content: '欢迎来到如何打击宿槐！作为宿槐的父亲，我为您准备了一份新手礼包，包含520阳光和一个初级植物，帮助您快速开始游戏！点击附件领取奖励，祝您游戏愉快！',
      isRead: false,
      summary: '欢迎来到如何打击宿槐！作为宿槐的父亲，我为您准备了一份新手礼包...',
      attachments: [
        {
          id: 'a1',
          type: 'sun',
          name: '阳光',
          icon: 'fa-sun',
          quantity: 520,
          isCollected: false,
          description: '用于种植植物的基础资源'
        },
        {
          id: 'a2',
          type: 'plant',
          name: '宿槐射手',
          icon: 'fa-seedling',
          quantity: 1,
          isCollected: false,
          description: '基础攻击型植物，发射宿槐攻击僵尸'
        }
      ]
    },
    {
      id: '3',
      title: '成就解锁通知',
      sender: '成就系统',
      senderAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=achievement%20system%20avatar%20trophy%20icon&sign=d1e79f844b3c72aaca30e782456c0cbf',
      time: '昨天',
      date: '2025-10-29',
      content: '恭喜您解锁了成就"光明的觉醒"！这是您在游戏中的第一个重要里程碑。继续努力，解锁更多成就，获得丰厚奖励！',
      isRead: false,
      summary: '恭喜您解锁了成就"光明的觉醒"！这是您在游戏中的第一个重要里程碑...',
      attachments: [
        {
          id: 'a3',
          type: 'achievement',
          name: '光明的觉醒',
          icon: 'fa-trophy',
          quantity: 1,
          isCollected: false,
          description: '首次胜利，光明之力在你手中苏醒'
        }
      ]
    },
    {
      id: '4',
      title: '版本更新通知',
      sender: '游戏团队',
      senderAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=game%20team%20avatar%20group%20icon&sign=7d414a4d36fbe6f107bcc8e69aafa9f6',
      time: '前天',
      date: '2025-10-28',
      content: '《光明与暗影之战》已更新至最新版本！新增了全新的角色、关卡和游戏模式，优化了游戏平衡性和性能表现。感谢您的支持和反馈！',
      isRead: true,
      summary: '《光明与暗影之战》已更新至最新版本！新增了全新的角色、关卡和游戏模式...',
      attachments: []
    },
    {
      id: '5',
      title: '限时活动：双倍阳光',
      sender: '活动中心',
      senderAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=event%20center%20avatar%20calendar%20icon&sign=7847f78d40f787d8c6f392c1f31afd7c',
      time: '3天前',
      date: '2025-10-27',
      content: '限时活动开启！未来48小时内，游戏内阳光产出提升至双倍！抓紧时间种植更多植物，挑战更高难度关卡吧！活动期间还将有特殊僵尸出现，击败它们可以获得额外奖励！',
      isRead: true,
      summary: '限时活动开启！未来48小时内，游戏内阳光产出提升至双倍！抓紧时间种植更多植物...',
      attachments: []
    }
  ];

  // 选择邮件
  const handleSelectMail = (mail: Mail) => {
    setSelectedMail(mail);
    setShowFullContent(false);
    
    // 标记为已读
    if (!mail.isRead) {
      setMails(prevMails => 
        prevMails.map(m => 
          m.id === mail.id ? { ...m, isRead: true } : m
        )
      );
      setUnreadCount(prevCount => Math.max(0, prevCount - 1));
    }
    
    // 在移动视图下切换到内容标签
    if (isMobileView) {
      setMobileTab('content');
    }
  };

  // 标记邮件为已读/未读
  const toggleMailReadStatus = (mailId: string) => {
    setMails(prevMails => 
      prevMails.map(mail => {
        if (mail.id === mailId) {
          const newIsRead = !mail.isRead;
          // 更新未读计数
          setUnreadCount(prevCount => 
            newIsRead ? Math.max(0, prevCount - 1) : prevCount + 1
          );
          return { ...mail, isRead: newIsRead };
        }
        return mail;
      })
    );
  };

  // 删除邮件
  const deleteMail = (mailId: string) => {
    setMails(prevMails => prevMails.filter(mail => mail.id !== mailId));
    
    // 如果删除的是当前选中的邮件，清除选中状态
    if (selectedMail && selectedMail.id === mailId) {
      setSelectedMail(null);
      if (isMobileView) {
        setMobileTab('list');
      }
    }
  };

  // 领取单个附件
  const collectAttachment = (mailId: string, attachmentId: string) => {
    setMails(prevMails => 
      prevMails.map(mail => {
        if (mail.id === mailId && mail.attachments) {
          const updatedAttachments = mail.attachments.map(attachment => 
            attachment.id === attachmentId 
              ? { ...attachment, isCollected: true } 
              : attachment
          );
          
          // 模拟领取奖励
          const attachment = mail.attachments.find(a => a.id === attachmentId);
          if (attachment) {
            toast(`已领取 ${attachment.name} × ${attachment.quantity}`);
          }
          
          return { ...mail, attachments: updatedAttachments };
        }
        return mail;
      })
    );
  };

  // 一键领取所有附件
  const collectAllAttachments = () => {
    if (!selectedMail) return;
    
    setMails(prevMails => 
      prevMails.map(mail => {
        if (mail.id === selectedMail.id && mail.attachments) {
          const uncollectedAttachments = mail.attachments.filter(a => !a.isCollected);
          
          // 模拟领取所有奖励
          uncollectedAttachments.forEach(attachment => {
            toast(`已领取 ${attachment.name} × ${attachment.quantity}`);
          });
          
          const updatedAttachments = mail.attachments.map(attachment => ({ 
            ...attachment, 
            isCollected: true 
          }));
          
          return { ...mail, attachments: updatedAttachments };
        }
        return mail;
      })
    );
  };

  // 一键领取所有邮件的附件
  const collectAllMailAttachments = () => {
    setMails(prevMails => 
      prevMails.map(mail => {
        if (mail.attachments && mail.attachments.some(a => !a.isCollected)) {
          const updatedAttachments = mail.attachments.map(attachment => ({ 
            ...attachment, 
            isCollected: true 
          }));
          
          // 模拟领取所有奖励
          mail.attachments.forEach(attachment => {
            if (!attachment.isCollected) {
              toast(`已领取 ${attachment.name} × ${attachment.quantity}`);
            }
          });
          
          return { ...mail, attachments: updatedAttachments, isRead: true };
        }
        return mail;
      })
    );
    
    setUnreadCount(0);
  };

  // 标记所有邮件为已读
  const markAllAsRead = () => {
    setMails(prevMails => 
      prevMails.map(mail => ({ ...mail, isRead: true }))
    );
    setUnreadCount(0);
  };

  // 格式化日期显示
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
      return '今天';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return '昨天';
    } else {
      return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' });
    }
  };

  // 回到首页
  const goBack = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 flex flex-col">
      {/* 头部导航栏 */}
      <header className="mb-6">
        <div className="flex items-center justify-between">
          <button 
            onClick={goBack}
            className="bg-gray-800 hover:bg-gray-700 text-white p-2 rounded-lg transition-all duration-300"
          >
            <i className="fa-solid fa-arrow-left"></i>
          </button>
          
          <h1 className="text-2xl font-bold text-center flex-1">
            <i className="fa-solid fa-inbox mr-2"></i>邮箱
          </h1>
          
          <div className="flex items-center bg-gray-800 px-4 py-2 rounded-full">
            <span className="text-sm mr-2">未读:</span>
            <span className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded-full">
              {unreadCount}
            </span>
          </div>
        </div>
      </header>

      {/* 主要内容区域 */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center flex-1">
          <div className="w-12 h-12 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin mb-4"></div>
          <p className="text-gray-400">加载邮件中...</p>
        </div>
      ) : (
        <>
          {isMobileView ? (
            // 移动端视图
            <>
              {/* 移动端标签切换 */}
              <div className="bg-gray-800 rounded-lg p-1 mb-4 flex">
                <button
                  onClick={() => setMobileTab('list')}
                  className={`flex-1 py-2 rounded-md text-center ${
                    mobileTab === 'list' ? 'bg-green-600 text-white' : 'text-gray-400'
                  }`}
                >
                  <i className="fa-solid fa-list-ul mr-1"></i> 邮件列表
                </button>
                <button
                  onClick={() => setMobileTab('content')}
                  className={`flex-1 py-2 rounded-md text-center ${
                    mobileTab === 'content' ? 'bg-green-600 text-white' : 'text-gray-400'
                  }`}
                  disabled={!selectedMail}
                >
                  <i className="fa-solid fa-envelope-open-text mr-1"></i> 阅读邮件
                </button>
              </div>

              <AnimatePresence mode="wait">
                {mobileTab === 'list' ? (
                  <motion.div
                    key="mobile-list"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                    className="flex-1"
                  >
                    <MailList
                      mails={mails}
                      selectedMailId={selectedMail?.id || ''}
                      onSelectMail={handleSelectMail}
                      onToggleReadStatus={toggleMailReadStatus}
                      onDeleteMail={deleteMail}
                      formatDate={formatDate}
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key="mobile-content"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="flex-1"
                  >
                    {selectedMail ? (
                      <MailContent
                        mail={selectedMail}
                        showFullContent={showFullContent}
                        onToggleFullContent={setShowFullContent}
                        onToggleReadStatus={toggleMailReadStatus}
                        onDeleteMail={deleteMail}
                        onCollectAttachment={collectAttachment}
                        onCollectAllAttachments={collectAllAttachments}
                      />
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-gray-400">
                        <i className="fa-solid fa-envelope text-4xl mb-4"></i>
                        <p>请选择一封邮件进行阅读</p>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* 移动端底部操作栏 */}
              <div className="mt-4 bg-gray-800 p-3 rounded-lg flex justify-between">
                <button
                  onClick={collectAllMailAttachments}
                  className="flex items-center text-green-400 hover:text-green-300 transition-colors"
                  disabled={mails.every(mail => !mail.attachments || mail.attachments.every(a => a.isCollected))}
                >
                  <i className="fa-solid fa-gift mr-1"></i>
                  <span className="text-sm">一键领取</span>
                </button>
                
                <button
                  onClick={markAllAsRead}
                  className="flex items-center text-blue-400 hover:text-blue-300 transition-colors"
                  disabled={unreadCount === 0}
                >
                  <i className="fa-solid fa-check-double mr-1"></i>
                  <span className="text-sm">全部已读</span>
                </button>
                
                <div className="text-gray-400 text-sm">
                  <span>共{unreadCount}封未读</span>
                </div>
              </div>
            </>
          ) : (
            // 桌面端视图 - 三栏布局
            <div className="flex-1 grid grid-cols-12 gap-4">
              {/* 左侧邮件列表 */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
                className="col-span-1 md:col-span-4 lg:col-span-4 bg-gray-800 rounded-xl overflow-hidden"
              >
                {/* 列表头部操作 */}
                <div className="p-4 border-b border-gray-700 flex justify-between items-center">
                  <h2 className="font-semibold">全部邮件 ({mails.length})</h2>
                  <div className="flex gap-2">
                    <button
                      onClick={markAllAsRead}
                      className="text-sm text-blue-400 hover:text-blue-300 transition-colors"
                      disabled={unreadCount === 0}
                    >
                      全部已读
                    </button>
                    <button
                      onClick={collectAllMailAttachments}
                      className="text-sm text-green-400 hover:text-green-300 transition-colors"
                      disabled={mails.every(mail => !mail.attachments || mail.attachments.every(a => a.isCollected))}
                    >
                      一键领取所有附件
                    </button>
                  </div>
                </div>
                
                {/* 邮件列表内容 */}
                <div className="h-[calc(100%-64px)] overflow-y-auto">
                  <MailList
                    mails={mails}
                    selectedMailId={selectedMail?.id || ''}
                    onSelectMail={handleSelectMail}
                    onToggleReadStatus={toggleMailReadStatus}
                    onDeleteMail={deleteMail}
                    formatDate={formatDate}
                  />
                </div>
              </motion.div>

              {/* 右侧邮件内容和附件 */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.1 }}
                className="col-span-1 md:col-span-8 lg:col-span-8"
              >
                {selectedMail ? (
                  <MailContent
                    mail={selectedMail}
                    showFullContent={showFullContent}
                    onToggleFullContent={setShowFullContent}
                    onToggleReadStatus={toggleMailReadStatus}
                    onDeleteMail={deleteMail}
                    onCollectAttachment={collectAttachment}
                    onCollectAllAttachments={collectAllAttachments}
                  />
                ) : (
                  <div className="bg-gray-800 rounded-xl h-full flex flex-col items-center justify-center text-gray-400 p-6">
                    <div className="text-6xl mb-4">📬</div>
                    <h2 className="text-xl font-semibold mb-2">收件箱</h2>
                    <p className="text-center max-w-md">
                      选择左侧邮件查看详细内容，或从底部领取所有邮件的附件奖励
                    </p>
                    
                    <div className="mt-8 flex flex-wrap gap-4 justify-center">
                      <button
                        onClick={markAllAsRead}
                        className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors"
                        disabled={unreadCount === 0}
                      >
                        <i className="fa-solid fa-check-double mr-2"></i> 标记全部为已读
                      </button>
                      <button
                        onClick={collectAllMailAttachments}
                        className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
                        disabled={mails.every(mail => !mail.attachments || mail.attachments.every(a => a.isCollected))}
                      >
                        <i className="fa-solid fa-gift mr-2"></i> 一键领取所有附件
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default MailPage;