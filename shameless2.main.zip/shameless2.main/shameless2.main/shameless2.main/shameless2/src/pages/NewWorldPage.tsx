import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import XinYaoLuModal from "../components/XinYaoLuModal";
import ContactModal from "../components/ContactModal";


// 可点击的介绍组件
const ClickableIntro: React.FC = () => {
  const navigate = useNavigate();
  const [active, setActive] = useState<boolean>(false);
  const prefetchLogin = () => {
    // 移除不支持的动态导入
    console.log('导航到登录页面准备中...');
  };
  const goLogin = () => {
    try {
      navigate('/login');
    } catch (err) {
      console.error('navigate to /login failed');
      try { window.history.pushState(null, '', '/login'); } catch {}
      window.location.assign('/login');
    }
  };
  const trigger = () => {
    prefetchLogin();
    setActive(true);
    window.clearTimeout((trigger as any)._t);
    (trigger as any)._t = window.setTimeout(() => {
      setActive(false);
      goLogin();
    }, 400);
  };
  return (
    <p
      role="link"
      tabIndex={0}
      aria-label="前往登录页面"
      onPointerDown={trigger}
      onTouchStart={trigger}
      onClick={trigger}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); trigger(); } }}
      className="text-gray-400 text-sm sm:text-base cursor-pointer select-none [touch-action:manipulation] [transition:transform_400ms_cubic-bezier(0.4,0,0.2,1),opacity_400ms_cubic-bezier(0.4,0,0.2,1)] [will-change:transform,opacity] focus:outline-none focus:ring-2 focus:ring-blue-500/50 rounded"
      style={{
        transform: active ? "translate3d(0,-4px,0) scale(1.025)" : "translate3d(0,0,0) scale(1)",
        opacity: active ? 0.9 : 1,
        WebkitTapHighlightColor: "transparent"
      }}>
      发现隐藏的秘密和全新的冒险
    </p>
  );
};

const FeatureCard: React.FC<{
    icon: string;
    title: string;
    delay: number;
    color: string;
    onClick?: () => void;
}> = (
    {
        icon,
        title,
        delay,
        color,
        onClick
    }
) => {
    return (
        <motion.div
            className="bg-gray-800/80 border border-blue-500/30 rounded-lg p-6 text-center cursor-pointer overflow-hidden relative group"
            initial={{
                opacity: 0,
                scale: 0.9
            }}
            animate={{
                opacity: 1,
                scale: 1
            }}
            transition={{
                duration: 0.5,
                delay
            }}
            whileHover={{
                scale: 1.03,
                borderColor: "rgba(59, 130, 246, 0.8)",
                backgroundColor: "rgba(30, 41, 59, 0.9)"
            }}
            whileTap={{
                scale: 0.98
            }}
            onClick={onClick}>
            {}
            <div
                className={`absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-r ${color}`}
                style={{
                    zIndex: -1
                }}></div>
            <div className="relative">
                <div
                    className={`text-3xl text-transparent bg-clip-text bg-gradient-to-r ${color} mb-4 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3`}>
                    <i className={`fa-solid ${icon}`}></i>
                </div>
                <h3 className="text-xl font-bold text-white tracking-wide">{title}</h3>
                {}
                <motion.div
                    className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 h-0.5 bg-blue-400 w-0 group-hover:w-1/2 transition-all duration-300"
                    whileHover={{
                        width: "70%"
                    }}></motion.div>
            </div>
        </motion.div>
    );
};

const NewWorldPage: React.FC = () => {
    const navigate = useNavigate();
    const [showModal, setShowModal] = useState<boolean>(true);
    const [showXinYaoLu, setShowXinYaoLu] = useState<boolean>(false);
    const [showContact, setShowContact] = useState<boolean>(false);
    const [showEasterEgg, setShowEasterEgg] = useState<boolean>(false);
    useEffect(() => {}, []);

    const handleCloseModal = () => {
        setShowModal(false);
    };

    const handleBackdropClick = (e: React.MouseEvent) => {
        if (e.target === e.currentTarget) {
            handleCloseModal();
        }
    };

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === "Escape") {
                if (showContact) {
                    setShowContact(false);
                } else if (showXinYaoLu) {
                    setShowXinYaoLu(false);
                } else if (showEasterEgg) {
                    setShowEasterEgg(false);
                } else if (showModal) {
                    handleCloseModal();
                }
            }
        };

        document.addEventListener("keydown", handleKeyDown);

        return () => {
            document.removeEventListener("keydown", handleKeyDown);
        };
    }, [showModal, showXinYaoLu, showContact, showEasterEgg]);

    return (
        <div
            className="min-h-screen bg-gradient-to-br from-gray-900 to-blue-950 flex flex-col">
            {}
            <header
                className="bg-gradient-to-r from-blue-900/90 to-purple-900/90 backdrop-blur-md py-3 px-6 md:px-8 flex justify-between items-center border-b border-blue-400/30 shadow-lg transition-all duration-300">
                <motion.button
                    whileHover={{
                        scale: 1.05,
                        backgroundColor: "rgba(37, 99, 235, 0.9)"
                    }}
                    whileTap={{
                        scale: 0.95
                    }}
                    onClick={() => navigate("/")}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-all duration-300 font-medium"
                    aria-label="返回主页">
                    <i className="fa-solid fa-arrow-left"></i>
                    <span className="hidden sm:inline">返回</span>
                </motion.button>
                <motion.h1
                    className="text-[clamp(1.5rem,4vw,2.5rem)] font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-300 to-cyan-200 tracking-wide cursor-pointer"
                    initial={{
                        opacity: 0,
                        y: -10
                    }}
                    animate={{
                        opacity: 1,
                        y: 0
                    }}
                    transition={{
                        duration: 0.5
                    }}
                    whileHover={{
                        scale: 1.05,
                        rotate: 1
                    }}
                    whileTap={{
                        scale: 0.98
                    }}
                    onClick={() => setShowXinYaoLu(true)}
                    title="点击查看心药录">新世界
                            </motion.h1>
                <div className="relative">
                    <motion.div
                        className="text-xl text-yellow-400 flex items-center gap-2 cursor-pointer font-medium"
                        whileHover={{
                            scale: 1.1,
                            rotate: 5
                        }}
                        whileTap={{
                            scale: 0.95
                        }}
                        onClick={() => setShowEasterEgg(true)}
                        title="点击查看彩蛋内容"
                        aria-label="彩蛋">
                        <i className="fa-solid fa-heart animate-pulse"></i>
                        <span className="text-yellow-300 hidden sm:inline">彩蛋</span>
                    </motion.div>
                </div>
            </header>
            {}
            <main
                className="flex-grow flex flex-col items-center justify-center p-4 sm:p-6 md:p-8"
                style={{
                    backgroundSize: "cover",
                    backgroundRepeat: "no-repeat",
                    backgroundPosition: "50% 50%"
                }}>
                <motion.div
                    className="max-w-3xl w-full bg-gray-900/90 backdrop-blur-md rounded-xl border border-blue-500/30 p-5 sm:p-6 shadow-xl"
                    initial={{
                        opacity: 0,
                        y: 20
                    }}
                    animate={{
                        opacity: 1,
                        y: 0
                    }}
                    transition={{
                        duration: 0.6,
                        delay: 0.2
                    }}
                    style={{
                        backgroundImage: "url(https://space-static.coze.site/coze_space/7561212695857447202/upload/3d48f67a08e43b3e5c46596c844022081b776dd519530-UHypu5_fw480webp.webp?sign=1765619182-3abb76ad3e-0-01f594e3b26c41ed2b4e14c65f8bc4ac3f4823c43d53b945227357f7d6414a4d)",
                        backgroundSize: "cover",
                        backgroundRepeat: "no-repeat",
                        backgroundPosition: "50% 50%"
                    }}>
                    {}
                    <motion.div
                        className="text-center mb-8"
                        initial={{
                            opacity: 0
                        }}
                        animate={{
                            opacity: 1
                        }}
                        transition={{
                            duration: 0.8,
                            delay: 0.4
                        }}>
                        <h2
                            className="text-2xl sm:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300 mb-2">探索未知世界
                                        </h2>
                        <ClickableIntro />
                    </motion.div>
                    {}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 sm:gap-6">
                        {}
                        <FeatureCard
                            icon="fa-book-open"
                            title="角色图鉴"
                            delay={0.5}
                            color="from-blue-500 to-indigo-600"
                            onClick={() => navigate("/worldview-classification")} />
                        {}
                        <FeatureCard
                            icon="fa-scroll"
                            title="剧情故事"
                            delay={0.6}
                            color="from-purple-500 to-pink-600" />
                        {}
                        <FeatureCard
                            key="fengyanfengyu"
                            icon="fa-comments"
                            title="锋言锋语"
                            delay={0.7}
                            color="from-orange-500 to-red-500"
                            onClick={() => navigate("/quotes")} />
                        {}
                        {Array.from({
                            length: 5
                        }).map((_, index) => <FeatureCard
                            key={index}
                            icon="fa-question"
                            title="未知"
                            delay={0.8 + index * 0.1}
                            color="from-gray-500 to-blue-500" />)}
                    </div>
                    {}
                    <motion.div
                        className="mt-8 text-center"
                        initial={{
                            opacity: 0
                        }}
                        animate={{
                            opacity: 1
                        }}
                        transition={{
                            duration: 0.8,
                            delay: 1.2
                        }}>
                        <motion.p
                            className="text-gray-400 text-sm flex items-center justify-center gap-2 cursor-pointer hover:text-blue-300 transition-colors"
                            whileHover={{
                                scale: 1.05
                            }}
                            whileTap={{
                                scale: 0.98
                            }}
                            onClick={() => setShowContact(true)}
                            title="点击查看联系方式">
                            <i className="fa-solid fa-headset text-blue-400"></i>
                            <span>有任何问题，请联系wixi</span>
                        </motion.p>
                    </motion.div>
                </motion.div>
            </main>
            {}
            <AnimatePresence>
                {showModal && <motion.div
                    initial={{
                        opacity: 0
                    }}
                    animate={{
                        opacity: 1
                    }}
                    exit={{
                        opacity: 0
                    }}
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50"
                    onClick={handleBackdropClick}>
                    <motion.div
                        initial={{
                            scale: 0.9,
                            y: 20
                        }}
                        animate={{
                            scale: 1,
                            y: 0
                        }}
                        exit={{
                            scale: 0.9,
                            y: 20
                        }}
                        className="bg-gray-900 border-2 border-blue-500 rounded-xl p-6 max-w-md w-full mx-4 relative"
                        onClick={e => e.stopPropagation()}>
                        <button
                            onClick={handleCloseModal}
                            className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
                            aria-label="关闭">
                            <i className="fa-solid fa-xmark text-xl"></i>
                        </button>
                        <div className="text-center">
                            <div className="text-5xl text-blue-400 mb-4">
                                <i className="fa-solid fa-lightbulb"></i>
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-4">恭喜你发现新大陆，祝你有新的收获</h3>
                            <motion.button
                                whileHover={{
                                    scale: 1.05
                                }}
                                whileTap={{
                                    scale: 0.95
                                }}
                                onClick={handleCloseModal}
                                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg">确定
                                                </motion.button>
                        </div>
                    </motion.div>
                </motion.div>}
            </AnimatePresence>
            {}
            <XinYaoLuModal isOpen={showXinYaoLu} onClose={() => setShowXinYaoLu(false)} />
            {}
            <ContactModal isOpen={showContact} onClose={() => setShowContact(false)} />
            {}
            <AnimatePresence>
                {showEasterEgg && <motion.div
                    initial={{
                        opacity: 0
                    }}
                    animate={{
                        opacity: 1
                    }}
                    exit={{
                        opacity: 0
                    }}
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50"
                    onClick={() => setShowEasterEgg(false)}>
                    <motion.div
                        initial={{
                            scale: 0.9,
                            y: 20
                        }}
                        animate={{
                            scale: 1,
                            y: 0
                        }}
                        exit={{
                            scale: 0.9,
                            y: 20
                        }}
                        className="bg-gray-900 border-2 border-yellow-500 rounded-xl p-6 max-w-md w-full mx-4 relative"
                        onClick={e => e.stopPropagation()}>
                        <button
                            onClick={() => setShowEasterEgg(false)}
                            className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
                            aria-label="关闭">
                            <i className="fa-solid fa-xmark text-xl"></i>
                        </button>
                        <div className="text-center">
                            <div className="text-3xl font-bold text-yellow-400 mb-4">第21条</div>
                            <div className="text-xl text-white mb-4">劝君莫惜金缕衣，劝君惜取少年时。</div>
                            <div className="text-xl text-white mb-6">花开堪折直须折，莫待无花空折枝。</div>
                            <motion.button
                                whileHover={{
                                    scale: 1.05
                                }}
                                whileTap={{
                                    scale: 0.95
                                }}
                                onClick={() => setShowEasterEgg(false)}
                                className="bg-yellow-600 hover:bg-yellow-700 text-white px-6 py-2 rounded-lg">确定
                                                </motion.button>
                        </div>
                    </motion.div>
                </motion.div>}
            </AnimatePresence>
        </div>
    );
};

export default NewWorldPage;


