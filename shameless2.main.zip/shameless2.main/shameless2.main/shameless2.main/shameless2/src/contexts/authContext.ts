import { createContext, useState, useContext, ReactNode, createElement, useEffect, useCallback } from 'react';

interface AuthContextType {
  isAuthenticated: boolean;
  username: string | null;
  token: string | null;
  csrfToken: string | null;
  login: (username: string) => void;
  logout: () => void;
  refreshCsrf: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => sessionStorage.getItem('isLoggedIn') === 'true');
  const [username, setUsername] = useState<string | null>(() => sessionStorage.getItem('username'));
  const [token, setToken] = useState<string | null>(() => sessionStorage.getItem('token'));
  const [csrfToken, setCsrfToken] = useState<string | null>(() => sessionStorage.getItem('csrfToken'));

  const stampActivity = useCallback(() => {
    sessionStorage.setItem('lastActive', String(Date.now()));
  }, []);

  useEffect(() => {
    const last = sessionStorage.getItem('lastActive');
    if (!last) stampActivity();
    if (!csrfToken) issueCsrf();
  }, [stampActivity]);

  const issueCsrf = () => {
    const buf = new Uint8Array(16);
    crypto.getRandomValues(buf);
    const c = Array.from(buf).map(b => b.toString(16).padStart(2, '0')).join('');
    setCsrfToken(c);
    sessionStorage.setItem('csrfToken', c);
  };

  const refreshCsrf = () => issueCsrf();

  const login = (user: string) => {
    const buf = new Uint8Array(16);
    crypto.getRandomValues(buf);
    const t = Array.from(buf).map(b => b.toString(16).padStart(2, '0')).join('');
    setIsAuthenticated(true);
    setUsername(user);
    setToken(t);
    sessionStorage.setItem('isLoggedIn', 'true');
    sessionStorage.setItem('username', user);
    sessionStorage.setItem('token', t);
    stampActivity();
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUsername(null);
    setToken(null);
    setCsrfToken(null);
    sessionStorage.removeItem('isLoggedIn');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('lastActive');
    sessionStorage.removeItem('csrfToken');
  };

  useEffect(() => {
    const onActivity = () => stampActivity();
    const check = () => {
      const last = Number(sessionStorage.getItem('lastActive') || 0);
      if (last && Date.now() - last > 30 * 60 * 1000) {
        logout();
      }
    };
    window.addEventListener('mousemove', onActivity, { passive: true });
    window.addEventListener('keydown', onActivity, { passive: true });
    window.addEventListener('touchstart', onActivity, { passive: true });
    const id = window.setInterval(check, 60 * 1000);
    return () => {
      window.removeEventListener('mousemove', onActivity);
      window.removeEventListener('keydown', onActivity);
      window.removeEventListener('touchstart', onActivity);
      window.clearInterval(id);
    };
  }, [stampActivity]);

  return createElement(
    AuthContext.Provider,
    { value: { isAuthenticated, username, token, csrfToken, login, logout, refreshCsrf } },
    children
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
